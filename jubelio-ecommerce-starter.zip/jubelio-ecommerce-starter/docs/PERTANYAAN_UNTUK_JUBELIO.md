# Pertanyaan untuk tim Jubelio (sebelum produksi)

Daftar hal yang **tidak jelas/ambigu** di API Contract v1.8 dan Guide Book. Jawabannya memengaruhi desain. Tandai ✅ saat sudah dijawab.

## A. Keamanan & webhook
1. [ ] **Algoritma signature**: teks dokumen "SHA256", contoh kode **HMAC-SHA256** dengan input `payload + secret`. Mana yang benar? Apakah `payload` = body mentah persis?
2. [ ] Nama event: contoh webhook `"event": "awb"`, contoh signature `"event":"Resi"`. Daftar lengkap nilai `event`?
3. [ ] **Kebijakan retry webhook** (berapa kali, jeda, kapan menyerah), batas waktu respons, jaminan urutan, kemungkinan duplikat?
4. [ ] Apakah ada **IP allowlist** sumber webhook?
5. [ ] Cara mengganti/rotasi `client_secret` dan webhook secret tanpa downtime?

## B. Pembuatan resi
6. [ ] **`ref_no`**: wajib tapi "auto generate" (`"[auto]"`). Bolehkah diisi nomor order kita? Harus unik? Apakah ada **idempotency** (request ulang dengan `ref_no` sama mengembalikan resi yang sama)?
7. [ ] Bisakah resi dicari dengan `ref_no` (hanya ada `GET /shipments/awb/{awb}` di kontrak)? Ini krusial untuk pulih dari timeout.
8. [ ] **`items[].value`**: harga per unit atau total baris? Dipakai untuk apa (asuransi/COD)?
9. [ ] **`shipping_insurance`** (request): nominal premi (seperti di respons rates), nilai pertanggungan, atau flag? Contoh kontrak `100`.
10. [ ] **Pickup**: tidak ada endpoint/parameter jadwal pickup. Apakah pickup otomatis saat resi dibuat? Bagaimana mengatur jam/tanggal? (Respons ada `pickup_timestamp`/`pickup_date`.)
11. [ ] Cara kerja `package_detail` vs `items` bila **keduanya** dikirim; pembagi volumetrik dan aturan pembulatan berat per kurir/kategori; batas dimensi/berat maksimum.
12. [ ] Apakah `area_id` wajib untuk kurir tertentu (Instant/Same Day butuh `coordinate`)? Perilaku bila `area_id` dan `zipcode` tidak cocok?

## C. COD
13. [ ] Panduan menyebut COD = pelanggan membayar **biaya pengiriman** tunai (WooCommerce menambah "COD fee"). Apakah nilai **barang** juga ditagih kurir? Tidak ada field `cod_amount` di kontrak — dari mana nominalnya dihitung?
14. [ ] Lewat API, `is_cod: true` pada `POST /shipments/create`: resi **langsung terbit** atau menunggu **konfirmasi WhatsApp** pelanggan seperti di dashboard? Nilai `cod_confirmation_status`? Bagaimana kita tahu pelanggan menolak (webhook? status?)
15. [ ] Daftar kurir COD terkini (panduan: baru J&T) dan cara mengatur wilayah COD via API (di dashboard: *Preferensi Kurir ▸ COD*).
16. [ ] Pencairan dana COD ke penjual: kapan, lewat apa (Wallet/rekening)?

## D. Keuangan & operasional
17. [ ] **Endpoint cek saldo Jubelio Wallet**? Bagaimana format error saat saldo < Rp50.000 (kode/pesan)?
18. [ ] Pembatalan resi: apakah biaya dikembalikan ke Wallet seketika atau di faktur bulan berikut?
19. [ ] Ada API untuk **faktur/tagihan** dan **klaim** (saat ini hanya dashboard)? Cashback dihitung dari "pengiriman reguler" — definisinya (kategori `REGULER` saja?)
20. [ ] Endpoint **cetak label** (ukuran A4/A6, PDF)? Bila tidak ada, bolehkah kami membuat label sendiri (format/ barcode wajib)?
21. [ ] Promo Gratis/Diskon Ongkir hanya untuk Jubelio Store: adakah rencana mendukung channel API? Arti field `discount_rates`, `final_rates`, `promotion` pada respons rates untuk akun API?

## E. Platform
22. [ ] Cara memperoleh **kredensial sandbox**; apakah sandbox mensimulasikan status tracking/webhook; apakah resi sandbox memotong Wallet?
23. [ ] **Rate limit** per endpoint (terutama `/rates/all` saat checkout ramai) dan `generate-token`; perilaku `401` saat token kedaluwarsa (kode/pesan).
24. [ ] Format error lengkap (400/401/404/422/429) — kontrak hanya mendokumentasikan 500.
25. [ ] SLA, jadwal maintenance, kanal eskalasi teknis.
26. [ ] Frekuensi pembaruan data wilayah (`/regions`) dan apakah respons `GET /regions` tanpa `name` dipaginasi (ukuran besar).
27. [ ] Preferensi Kurir per gudang: bagaimana API tahu **gudang mana** untuk memfilter rates (apakah dari `origin`/Location Management)?
