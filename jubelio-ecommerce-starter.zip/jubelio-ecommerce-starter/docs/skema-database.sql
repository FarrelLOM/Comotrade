-- Skema contoh (PostgreSQL) untuk menggantikan src/store/db.js (in-memory).
-- Tujuan: menunjukkan KONSTRAINT yang membuat integrasi pengiriman aman, bukan skema lengkap ecommerce.

CREATE TABLE warehouses (
  id            BIGSERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  phone         TEXT NOT NULL,
  email         TEXT,
  address       TEXT NOT NULL,
  area_id       TEXT,                 -- kode kelurahan Jubelio (hasil /regions)
  zipcode       TEXT NOT NULL,
  coordinate    TEXT                  -- format kontrak: "(-6.212,106.821)"
);

CREATE TABLE orders (
  id               TEXT PRIMARY KEY,  -- nomor order milikmu
  status           TEXT NOT NULL,     -- PENDING_PAYMENT | READY_TO_SHIP | AWAITING_PICKUP | SHIPPED | SHIPMENT_ISSUE | DELIVERED | RETURNED
  customer_name    TEXT NOT NULL,
  customer_phone   TEXT NOT NULL,
  customer_email   TEXT,
  address          TEXT NOT NULL,
  area_id          TEXT,
  zipcode          TEXT NOT NULL,
  coordinate       TEXT,
  subtotal         BIGINT NOT NULL,
  shipping_buyer   BIGINT NOT NULL,   -- yang dibayar pembeli
  total            BIGINT NOT NULL,
  payment_method   TEXT NOT NULL,     -- TRANSFER | COD
  payment_status   TEXT NOT NULL,
  -- SNAPSHOT pilihan kurir saat checkout (tarif bisa berubah kemudian)
  courier_id       INT NOT NULL,
  courier_service_id INT NOT NULL,
  courier_name     TEXT NOT NULL,
  service_name     TEXT NOT NULL,
  carrier_price    BIGINT NOT NULL,   -- field `rates` (BUKAN final_rates) saat checkout
  subsidy          BIGINT NOT NULL DEFAULT 0,
  insurance        BIGINT NOT NULL DEFAULT 0,
  cod_fee          BIGINT NOT NULL DEFAULT 0,
  with_insurance   BOOLEAN NOT NULL DEFAULT FALSE,
  is_cod           BOOLEAN NOT NULL DEFAULT FALSE,
  package_json     JSONB NOT NULL,    -- berat (gram) + dimensi (cm) paket
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id          BIGSERIAL PRIMARY KEY,
  order_id    TEXT NOT NULL REFERENCES orders(id),
  sku         TEXT NOT NULL,
  name        TEXT NOT NULL,
  price       BIGINT NOT NULL,
  quantity    INT NOT NULL CHECK (quantity > 0),
  weight_gram INT NOT NULL CHECK (weight_gram > 0),
  length_cm   INT NOT NULL, width_cm INT NOT NULL, height_cm INT NOT NULL
);

CREATE TABLE shipments (
  id                   BIGSERIAL PRIMARY KEY,
  order_id             TEXT NOT NULL REFERENCES orders(id),
  state                TEXT NOT NULL,  -- CREATING | CREATED | UNKNOWN | FAILED | CANCELED  (state di sisi KITA)
  attempts             INT  NOT NULL DEFAULT 1,
  awb                  TEXT UNIQUE,
  jubelio_shipment_id  BIGINT,
  status               TEXT,           -- latest_status Jubelio: WAITING ... DELIVERED
  last_event_at        TIMESTAMPTZ,
  price                BIGINT,         -- harga riil dari respons create -> cocokkan dengan tagihan bulanan
  price_drift          BIGINT,
  tracking_url         TEXT,
  proof_json           JSONB,          -- delivered_img_url, sign_img_url, pod_url, live_tracking_url
  error_json           JSONB,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- KUNCI IDEMPOTENSI: satu order hanya boleh punya SATU shipment aktif.
-- INSERT kedua dengan state aktif akan gagal di database, bukan hanya di kode.
CREATE UNIQUE INDEX one_active_shipment_per_order
  ON shipments (order_id)
  WHERE state IN ('CREATING', 'CREATED', 'UNKNOWN');

CREATE TABLE shipment_events (
  id          BIGSERIAL PRIMARY KEY,
  shipment_id BIGINT NOT NULL REFERENCES shipments(id),
  event_at    TIMESTAMPTZ NOT NULL,
  status_code TEXT NOT NULL,           -- kode mentah kurir (F02, S01, D09, ...): hanya untuk tampilan
  detail      TEXT,
  source      TEXT NOT NULL,           -- webhook | reconcile | manual
  UNIQUE (shipment_id, status_code, event_at)   -- dedup event
);

CREATE TABLE webhook_events (
  dedupe_key  TEXT PRIMARY KEY,        -- awb|latest_status|status|date
  payload     JSONB NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
