# Referensi API Jubelio Shipment v1.8 (ringkasan + jebakan)

Sumber: *API Contract Jubelio Shipment v1.8* (dibuat 28-06-2023, maintainer: Jubelio API Team). Ringkasan ini **bukan pengganti** dokumen resmi.
Semua body JSON. Header `Authorization: Bearer <token>` (kontrak mewajibkannya untuk shipments & rates; klien di proyek ini mengirimnya ke semua endpoint).

Base URL — production: `https://api-shipment.jubelio.com` · staging: `https://api-shipment.sandbox.jubelio.com`

---

## 1. Auth

`POST /auth/generate-token`
```json
{ "client_id": "...", "client_secret": "..." }
```
→ `200 { "token": "...", "expires_in": 86400 }` (detik; di tabel dokumen bertipe string, di contoh number → normalisasi ke Number).
Kredensial didapat setelah terintegrasi: dashboard **Setting ▸ Developer**.

## 2. Wilayah (Region)

| Endpoint | Hasil |
|---|---|
| `GET /regions?name=jakarta` | daftar `{ name, province, city, district, area, area_id, zipcode }` (tanpa `name` = seluruh wilayah) |
| `GET /region/provinces` | `{ province_id, name }` |
| `GET /region/cities/{province_id}` | `{ city_id, province_id, name }` |
| `GET /region/districts/{city_id}` | `{ district_id, city_id, name }` |
| `GET /region/areas/{district_id}` | `{ area_id, district_id, name, zipcode }` |

`area_id` = kode kelurahan/desa (10 digit). Hierarki: provinsi → kota/kab → kecamatan → kelurahan.
**Praktik:** simpan `area_id` **dan** `zipcode` di alamat; cache hierarki (jarang berubah).

## 3. Kategori layanan

`GET /services/categories` → `1 REGULER · 2 EKONOMI · 3 NEXTDAY · 4 INSTANT · 5 SAMEDAY · 6 CARGO`

## 4. Ongkir (Rates)

`POST /rates` (satu kategori, **wajib** `service_category_id`) dan `POST /rates/all` (semua kurir):
```json
{
  "origin":      { "area_id": "3174021004", "zipcode": "12920", "coordinate": "(-6.2121761,106.8182448)" },
  "destination": { "area_id": "3175101006", "zipcode": "17425", "coordinate": "(-6.2849728,106.9000862)" },
  "package_detail": { "width": 20, "height": 5, "length": 30, "weight": 1000 },
  "items": [{ "quantity": 1, "weight": 100, "length": 30, "width": 20, "height": 5 }],
  "weight": 1000,
  "service_category_id": 1,
  "total_value": 40000
}
```
- Wajib: `origin.zipcode`, `destination.zipcode`, `weight` (**gram**), (`service_category_id` hanya untuk `/rates`). Dimensi dalam **cm**.
- Volumetrik: isi **salah satu** `items` **atau** `package_detail` (catatan kontrak). Proyek ini mengirim `package_detail`.
- `total_value` dipakai menghitung asuransi.

Respons: array
```json
{ "courier_id": 11, "courier_name": "JNE", "rates": 70000, "courier_service_id": 1101,
  "courier_service_code": "REG", "courier_service_name": "JNE REG", "courier_service_category": "REGULER",
  "eta_from": "...", "eta_to": "...", "is_cod_supported": false, "courier_logo": "",
  "shipping_insurance": 5700, "cod_fee": null, "discount_rates": 0, "final_rates": 70000, "promotion": null }
```
> ⚠️ **Gunakan `rates`, bukan `final_rates`** untuk perhitungan ongkir (ditegaskan kontrak).
> ⚠️ Hasil dibatasi oleh **Preferensi Kurir** yang diatur di dashboard (per gudang).

## 5. Buat resi

`POST /shipments/create`
```json
{
  "ref_no": "[auto]",
  "courier_id": 13, "courier_service_id": 1327,
  "shipping_insurance": 100,
  "is_cod": true,
  "origin":      { "name": "Toko Lala", "email": "...", "phone": "081...", "address": "Jl. Pengirim", "area_id": "3174021003", "coordinate": "(-6.212,106.821)", "zipcode": "12940" },
  "destination": { "name": "are", "phone": "081...", "address": "Jl. Penerima", "area_id": "3174041003", "coordinate": null, "zipcode": "12560" },
  "package_detail": { "width": 20, "height": 5, "length": 30 },
  "items": [{ "item_code": "X3505", "item_name": "...", "category": "-", "quantity": 1, "value": 125996, "weight": 2000, "length": 10, "width": 10, "height": 10 }]
}
```
Wajib: `ref_no`, `courier_id`, `courier_service_id`, `origin`/`destination` (`name`, `phone`, `address`, `zipcode`), `items` (`item_name`, `quantity`, `value`, `weight` gram, `length`, `width`, `height`).
Opsional: `shipping_insurance`, `is_cod`, `email`, `area_id`, `coordinate`, `package_detail`, `item_code`, `category`.
→ `200 { "shipment_id": 1281, "awb": "...", "tracking_url": "...", "price": 20000, "extra_info": {} }`
> ⚠️ Saldo Jubelio Wallet < Rp50.000 → gagal. ⚠️ Timeout = hasil **tidak diketahui**; jangan retry buta (lihat README §7.7).
> ❓ Ambigu: `ref_no` ("auto generate"), `items[].value` per unit/total, arti angka `shipping_insurance`, semantik COD.

## 6. Batalkan resi

`POST /shipments/cancel` → body `{ "cancel_reason": "Barang belum siap", "awb_code": "CM..." }`
→ `200 { "status": "cancel successful", "awb_code", "courier_name", "ref_no" }`
Gagal (HTTP 500 menurut kontrak) dengan `message`: `the courier do not accept cancellation` atau `too close with pickup schedule`.
Hanya bisa **sebelum kurir mengambil barang**.

## 7. Detail resi

`GET /shipments/awb/{awb}` → objek besar: `shipment_id, ref_no, awb, courier_*, service_category_*, price, price_bill, latest_status, pickup_timestamp, eta_from/eta_to, is_insurance, shipping_insurance, origin_*/destination_*, is_cod, cod_fee, cod_confirmation_status, cod_rejected_reason, delivered_img_url, items[], tracking[] { date, status, status_detail }, tracking_url, live_tracking_url, canceled_*, ...`

`latest_status`: `WAITING · CONFIRMED_BY_COURIER · ON_THE_WAY_PICK_UP · PICKED_UP · ON_DELIVERY · ON_HOLD · DELIVERED · RETURNED · CANCELED · SHIPMENT_ISSUE`
`tracking[].status` = **kode mentah kurir** (mis. `F02` pickup gagal, `S01` sukses pickup, `RC1`, `OP1`, `OP3`, `IP2`, `IP3` dengan kurir, `D09` delivered) — berbeda per kurir.

## 8. Webhook

Diatur di dashboard: **Setting ▸ Developer ▸ Webhook**. Jubelio mengirim `POST` ke URL milikmu dengan header `x-jubelio-signature`:
```json
{
  "event": "awb", "ref_no": "SH-00000000001", "awb": "xxxxxx", "shipment_id": 1, "latest_status": "CANCELED",
  "courier": { "courier_id": 24, "courier_service_id": 2452, "courier_name": "Lion Parcel", "courier_service_name": "Lion Parcel REGPACK", "service_category_name": "REGULER" },
  "delivered_img_url": "https://...", "sign_img_url": "https://...", "live_tracking_url": "https://...",
  "tracking_url": "https://...", "pod_url": "https://...",
  "tracking": { "date": "2025-01-01T08:56:32.375000Z", "status": "CNCL", "status_detail": "Barang belum siap" }
}
```
Perhatikan: di webhook `tracking` adalah **SATU objek**, di detail resi adalah **array**.

**Signature** (dari contoh kode kontrak):
```js
const crypto = require('crypto');
const signature = crypto.createHmac('sha256', secret).update(payload + secret).digest('hex');
// bandingkan dengan request.headers['x-jubelio-signature']
```
`payload` = string body persis seperti diterima. ⚠️ Teks kontrak hanya menyebut "SHA256" sedangkan kodenya HMAC-SHA256; contoh payload memakai `"event":"Resi"` padahal contoh webhook `"awb"`. Uji di sandbox.

## 9. Format error (yang terdokumentasi)

```json
{ "statusCode": 500, "error": "Internal Server Error", "message": "An internal server error occurred" }
```
Kontrak **hanya** mendokumentasikan respons 500, termasuk untuk kegagalan bisnis (mis. pembatalan ditolak). Kode status lain (400/401/404/429) tidak dijelaskan → tangani semua `!res.ok` secara generik dan jangan menggantungkan logika pada HTTP status saja (baca `message`).
