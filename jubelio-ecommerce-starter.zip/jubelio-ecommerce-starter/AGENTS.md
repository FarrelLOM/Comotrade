# AGENTS.md — peta proyek untuk asisten AI

Proyek referensi: integrasi **Jubelio Shipment** ke platform ecommerce custom (Node.js ≥18, Express 4, CommonJS, tanpa TypeScript). Baca `README.md` dulu (konsep + algoritma). Bahasa dokumentasi & komentar: **Indonesia**.

## Perintah
- `npm install` · `npm run dev:all` (mock + app) · `npm run dev` · `npm run mock` · `npm test` (node:test, 23 test)

## Peta kode
| Lokasi | Peran |
|---|---|
| `src/container.js` | satu-satunya tempat merakit objek (DI manual). Tambah service baru DI SINI |
| `src/lib/jubelioClient.js` | satu-satunya pintu ke API Jubelio (satu method per endpoint) |
| `src/lib/tokenManager.js` | cache token + single-flight refresh |
| `src/lib/signature.js` | hitung/verifikasi signature webhook |
| `src/domain/shippingStatus.js` | status, transisi, pemetaan status order (tanpa I/O) |
| `src/services/*` | logika bisnis; menerima dependensi lewat factory `createXxxService({...})` |
| `src/routes/*` | adaptor HTTP tipis; bungkus handler async dengan `asyncHandler` |
| `src/store/db.js` | penyimpanan in-memory (antarmuka yang harus ditiru bila ganti DB) |
| `mock/jubelioMockServer.js` | mock API + skenario gagal (`/__mock/*`) |
| `testing/helpers.js`, `test/*.test.js` | perakit test & test; setiap test membuat mock + container sendiri |

## Aturan yang harus dipatuhi saat mengubah/menambah kode
1. **Satuan**: berat **gram**, dimensi **cm**, uang **rupiah integer**.
2. **Ongkir**: pakai `rates`, **bukan** `final_rates`. Harga/berat produk selalu dari katalog server, bukan dari body request. Re-quote di server saat order dibuat.
3. **Jangan** retry otomatis `POST` ke Jubelio (khususnya `/shipments/create`). Timeout ⇒ `JubelioError.outcomeUnknown = true` ⇒ state `UNKNOWN`.
4. Perubahan status pengiriman **hanya** lewat `trackingService.applyStatusUpdate` (dipakai webhook & rekonsiliasi). Jangan logika bisnis dari kode status mentah kurir.
5. Webhook: verifikasi dari **raw body** (`req.rawBody`), balas 200 cepat, proses di belakang, idempotent.
6. Jangan log rahasia (`logger` sudah meredaksi key bernama secret/token/authorization/signature).
7. Error yang dikenal: turunan `AppError` (`ValidationError`, `ConflictError`, `NotFoundError`, `JubelioError`); route tidak menangkap error sendiri.
8. Setiap perilaku baru ⇒ tambah test di `test/flow.test.js` (integrasi terhadap mock) atau `test/unit.test.js`. Jalankan `npm test` sebelum selesai.
9. Hal ambigu dari dokumen Jubelio dicatat di `docs/PERTANYAAN_UNTUK_JUBELIO.md`, bukan ditebak diam-diam.

## Cara menambah fitur khas
- **Endpoint Jubelio baru**: method di `jubelioClient` → endpoint di mock → service → route → test → baris di `docs/API_REFERENSI.md`.
- **Ganti penyimpanan**: implementasikan antarmuka `createStore()` (lihat `docs/skema-database.sql` untuk konstrain).
