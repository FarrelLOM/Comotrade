'use strict';
/**
 * Hitung signature webhook untuk uji manual dengan curl.
 *   node scripts/signWebhook.js '<json-body>' [secret]
 * Contoh:
 *   node scripts/signWebhook.js '{"event":"awb","awb":"X","latest_status":"DELIVERED"}'
 */
const { computeSignature } = require('../src/lib/signature');

const [, , body, secret = process.env.JUBELIO_WEBHOOK_SECRET || 'mock-webhook-secret'] = process.argv;
if (!body) {
  console.error("Pemakaian: node scripts/signWebhook.js '<json-body>' [secret]");
  process.exit(1);
}
const sig = computeSignature(body, secret);
console.log(`x-jubelio-signature: ${sig}\n`);
console.log(`curl -X POST http://localhost:3000/webhooks/jubelio \\\n  -H "Content-Type: application/json" \\\n  -H "x-jubelio-signature: ${sig}" \\\n  -d '${body}'`);
