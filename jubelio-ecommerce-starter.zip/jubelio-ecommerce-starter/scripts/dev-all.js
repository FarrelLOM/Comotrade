'use strict';
/**
 * Menjalankan MOCK Jubelio + aplikasi sekaligus (satu terminal): npm run dev:all
 * Aplikasi otomatis diarahkan ke mock; webhook mock diarahkan ke aplikasi.
 */
const { spawn } = require('node:child_process');
const path = require('node:path');

const root = path.join(__dirname, '..');
const appPort = process.env.PORT || '3000';
const mockPort = process.env.MOCK_PORT || '4010';

const creds = { JUBELIO_CLIENT_ID: 'mock-client', JUBELIO_CLIENT_SECRET: 'mock-secret', JUBELIO_WEBHOOK_SECRET: 'mock-webhook-secret' };
const children = [];

function run(name, args, env) {
  const child = spawn(process.execPath, args, { cwd: root, env: { ...process.env, ...creds, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  const tag = (stream) => (chunk) => String(chunk).split('\n').filter(Boolean).forEach((l) => stream.write(`[${name}] ${l}\n`));
  child.stdout.on('data', tag(process.stdout));
  child.stderr.on('data', tag(process.stderr));
  child.on('exit', (code) => { console.log(`[${name}] berhenti (kode ${code})`); shutdown(); });
  children.push(child);
}

function shutdown() {
  for (const c of children) if (!c.killed) c.kill();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

run('mock', ['mock/jubelioMockServer.js'], { MOCK_PORT: mockPort, MOCK_WEBHOOK_URL: `http://localhost:${appPort}/webhooks/jubelio` });
setTimeout(() => run('app', ['--watch', 'src/server.js'], { PORT: appPort, JUBELIO_BASE_URL: `http://localhost:${mockPort}` }), 400);
