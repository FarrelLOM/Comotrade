# Jubelio Shipment — Starter untuk Platform Ecommerce Custom (Node.js / Express)

Proyek **referensi belajar**: contoh lengkap mengintegrasikan **Jubelio Shipment** (agregator ekspedisi: ongkir, resi/AWB, tracking, COD) ke platform ecommerce buatan sendiri — *bukan* WooCommerce.
Isinya kode yang bisa dijalankan, **mock server Jubelio** (tanpa kredensial), 23 test otomatis, dan dokumentasi algoritma.

> **Status & kejujuran:** semua kode diuji terhadap **mock server** yang meniru *API Contract Jubelio Shipment v1.8*. Kode **belum pernah** dijalankan ke API Jubelio sungguhan. Beberapa hal di dokumen Jubelio ambigu (lihat [`docs/PERTANYAAN_UNTUK_JUBELIO.md`](docs/PERTANYAAN_UNTUK_JUBELIO.md)); uji di **sandbox** sebelum produksi. ID kurir/layanan di mock sebagian fiktif.

---

## 1. Cara memakai proyek ini di VS Code

1. Ekstrak zip → **File ▸ Open Folder** → pilih folder `jubelio-ecommerce-starter`.
2. Terima rekomendasi ekstensi (**REST Client**, **Markdown Mermaid**).
3. Biarkan VS Code / asisten AI-mu (Copilot, Claude Code, dsb.) mengindeks folder ini. Titik masuk yang sengaja disiapkan untuk indeks:
   - [`README.md`](README.md) (file ini) — konsep, alur, algoritma
   - [`AGENTS.md`](AGENTS.md) + [`.github/copilot-instructions.md`](.github/copilot-instructions.md) — peta kode & aturan yang harus dipatuhi
   - [`docs/API_REFERENSI.md`](docs/API_REFERENSI.md) — ringkasan semua endpoint Jubelio + jebakannya
4. Contoh perintah ke asisten AI:
   > *"Baca README.md dan AGENTS.md. Lalu buat modul `returns` (retur barang) untuk platform saya dengan pola yang sama seperti `shipmentService`: dependency injection lewat container, error lewat `AppError`, dan test dengan mock."*

**Urutan membaca kode yang disarankan** (dari fondasi ke atas):
`src/lib/tokenManager.js` → `src/lib/jubelioClient.js` → `src/services/shippingCalc.js` → `src/services/rateService.js` → `src/services/shipmentService.js` → `src/domain/shippingStatus.js` → `src/services/trackingService.js` → `src/services/webhookService.js` → `mock/jubelioMockServer.js` → `test/flow.test.js`.

---

## 2. Quick start (±3 menit)

Prasyarat: **Node.js ≥ 18.18** (diuji di Node 22).

```bash
npm install
cp .env.example .env        # Windows: copy .env.example .env
npm run dev:all             # mock Jubelio (:4010) + aplikasi (:3000) sekaligus
```

Lalu buka [`examples/requests.http`](examples/requests.http) dan klik **Send Request** dari atas ke bawah
(cari alamat → ongkir → buat order → bayar → buat resi → simulasi kurir → tracking → batalkan).

Perintah lain:

| Perintah | Fungsi |
|---|---|
| `npm run dev:all` | Mock + aplikasi satu terminal (kredensial mock otomatis) |
| `npm run dev` | Hanya aplikasi, membaca `.env` (auto-reload) |
| `npm run mock` | Hanya mock server Jubelio |
| `npm test` | 23 test (unit + integrasi terhadap mock) |
| `npm run sign -- '<json>'` | Hitung signature webhook untuk uji `curl` |

F5 di VS Code: konfigurasi **Mock + App (debug keduanya)** sudah disediakan di `.vscode/launch.json`.

**Pindah ke sandbox/produksi Jubelio:** ubah `.env` → `JUBELIO_BASE_URL=https://api-shipment.sandbox.jubelio.com` (atau production `https://api-shipment.jubelio.com`), isi `JUBELIO_CLIENT_ID`, `JUBELIO_CLIENT_SECRET`, `JUBELIO_WEBHOOK_SECRET`, dan data gudang `WAREHOUSE_*`.

---

## 3. Tentang Jubelio Shipment

*(Sumber: Guide Book Jubelio Shipment & API Contract v1.8 yang kamu berikan.)*

**Apa itu?** Fitur Jubelio yang menghubungkan toko online dengan banyak partner logistik lewat **satu integrasi**: tarif banyak kurir, pembuatan resi, pelacakan, pembatalan, COD, dan penagihan terpusat. Enam kategori layanan: **Reguler, Ekonomi, Next Day, Instant, Same Day, Cargo**.

### 3.1 Prasyarat akun
1. Daftar **Account Center** Jubelio (satu login untuk semua produk Jubelio; boleh hanya Shipment).
2. **Jubelio Wallet** harus berisi **minimal Rp50.000** — jika kurang, *Ambil Resi* **gagal**.
3. Ambil `client_id` & `client_secret` di dashboard: **Setting ▸ Developer**. Webhook diatur di menu yang sama.
4. Pengguna Account Center: **Admin** (semua menu) atau **Standard** (semua kecuali saldo Wallet perusahaan).

### 3.2 Menu dashboard
| Menu | Isi |
|---|---|
| **Dashboard** | 5 tab: Semua, Menunggu (belum ada resi), Berlangsung, Bermasalah, Selesai. Tombol **+ Buat Pengiriman** |
| **Promosi** | Diskon Ongkir / Gratis Ongkir (lihat batasan di bawah) |
| **Tagihan** | Faktur bulanan, tab *Transaksi Bulan Ini* |
| **Lacak Klaim** | Status klaim paket hilang/rusak |
| **Setting** | Preferensi Kurir, Developer (API key/webhook), Label Pengiriman, Location Management (alamat gudang) |
| **Aktivitas Ekspor/Impor** | Log ekspor, mis. PDF label |

### 3.3 Aturan bisnis penting
- **Tagihan:** dibuat otomatis **tiap tanggal 1**; status `UNPAID` → `PAID`; ada **dispute** (tagihan salah diganti, yang lama berstatus `VOID`). Selisih belum bayar dibawa ke bulan berikutnya.
- **Cashback:** 5% dari total tagihan pengiriman *reguler* bila pengiriman selesai < 100/bulan; **15%** bila ≥ 100/bulan; diklaim sebagai potongan tagihan bulan berikutnya.
- **Preferensi Kurir:** kurir/jenis layanan aktif diatur per gudang; rates yang kamu dapat hanya dari yang diaktifkan.
- **COD:** hanya untuk wilayah (provinsi) & kurir yang diatur di *Preferensi Kurir ▸ COD*. Saat panduan ditulis **baru J&T** yang mendukung COD. Di dashboard, pelanggan menerima **WhatsApp berisi link konfirmasi** (terima/tolak) dan resi baru bisa diambil setelah dikonfirmasi.
- **Klaim paket hilang/rusak:** **tidak bisa diajukan penjual** — dimulai tim Ops Jubelio; penjual hanya melihat statusnya (Open → Investigate → Solved/Declare Missing → Submitted Claim → Approved → Claim Proceed → Claim Refund).
- **Pembatalan resi:** hanya sebelum kurir mengambil barang; bisa ditolak (kurir tidak mengizinkan / waktu pickup terlalu dekat).

### 3.4 Apa yang berlaku untuk platform custom (penting!)
Guide Book sebagian besar membahas dashboard dan **plugin WooCommerce**. Untuk platformmu, **hanya API yang relevan**:

| Fitur | Via API? | Catatan untuk platformmu |
|---|---|---|
| Ongkir, buat/batalkan resi, detail, tracking | ✅ | inti proyek ini |
| Webhook status | ✅ | inti proyek ini |
| Plugin WooCommerce (checkout, tombol *Generate AWB*) | ❌ | **peran plugin ini yang kamu tulis sendiri** |
| Promo Gratis/Diskon Ongkir | ❌ | hanya channel **Jubelio Store** → hitung subsidi sendiri (`rateService.computeBuyerShipping`) |
| Cetak label | ❓ tidak ada di kontrak | dari dashboard (A4/A6); tanyakan ke Jubelio apakah ada endpoint |
| Klaim | ❌ | dashboard (read-only) |
| Cek saldo Wallet | ❓ tidak ada di kontrak | pantau lewat kegagalan create resi / tanyakan ke Jubelio |
| Tagihan/faktur | ❌ | dashboard; rekonsiliasi pakai field `price` dari respons create resi |

---

## 4. Peta API Jubelio (v1.8)

Base URL: production `https://api-shipment.jubelio.com` · staging `https://api-shipment.sandbox.jubelio.com`. Detail lengkap: [`docs/API_REFERENSI.md`](docs/API_REFERENSI.md).

| Fungsi | Endpoint | Di kode |
|---|---|---|
| Token (berlaku 86400 dtk) | `POST /auth/generate-token` | `lib/tokenManager.js` |
| Kategori layanan | `GET /services/categories` | `jubelioClient.getServiceCategories` |
| Cari wilayah (autocomplete) | `GET /regions?name=` | `services/regionService.js` |
| Provinsi/kota/kecamatan/kelurahan | `GET /region/provinces`, `/cities/{id}`, `/districts/{id}`, `/areas/{id}` | `regionService` |
| Ongkir satu kategori | `POST /rates` | `rateService.getQuotes` |
| Ongkir semua kurir | `POST /rates/all` | `rateService.getQuotes` |
| Buat resi | `POST /shipments/create` | `shipmentService.createForOrder` |
| Batalkan resi | `POST /shipments/cancel` | `shipmentService.cancelForOrder` |
| Detail + riwayat resi | `GET /shipments/awb/{awb}` | `getLiveDetail`, `reconcileStale` |
| Webhook (dikirim Jubelio ke URL-mu) | `x-jubelio-signature` | `routes/webhooks.js`, `webhookService` |

---

## 5. Arsitektur & struktur folder

```
src/
  server.js            entrypoint (dotenv, listen, job rekonsiliasi opsional)
  app.js               rakit Express: raw body, route, error handler
  container.js         composition root (dependency injection manual)
  config/env.js        konfigurasi dari environment
  lib/                 tokenManager, jubelioClient, signature, errors, logger
  domain/              shippingStatus (status, aturan transisi, pemetaan order)
  services/            region, rate, order, shipment, tracking, webhook, shippingCalc
  routes/              regions, shipping, orders, webhooks  (tipis; logika di services)
  store/db.js          penyimpanan in-memory (ganti dengan DB: docs/skema-database.sql)
  data/products.json   katalog contoh (harga/berat/dimensi dari SERVER)
mock/                  mock server Jubelio + skenario gagal
testing/helpers.js     perakit test (mock + container + penerima webhook)
test/                  unit.test.js, flow.test.js
examples/requests.http klik-kirim untuk REST Client
docs/                  API_REFERENSI, PERTANYAAN_UNTUK_JUBELIO, skema-database.sql
scripts/               dev-all.js, signWebhook.js
```

Aturan ketergantungan: `routes → services → lib(client)`; `services` tidak tahu soal Express; `domain` tidak tahu soal HTTP/Jubelio. Semua dirakit di `container.js` sehingga test bisa merakit versinya sendiri.

---

## 6. Alur end-to-end

```mermaid
sequenceDiagram
  autonumber
  participant B as Pembeli
  participant P as Platform (Express)
  participant J as Jubelio Shipment API
  participant K as Kurir

  B->>P: Ketik alamat
  P->>J: GET /regions?name=...
  J-->>P: area_id + zipcode
  B->>P: Checkout (keranjang)
  P->>J: POST /rates/all (berat gram, dimensi cm, nilai)
  J-->>P: daftar layanan + ongkir
  B->>P: Pilih kurir + bayar
  Note over P: Server mengambil ULANG tarif, harga tidak dipercaya dari browser<br/>Simpan SNAPSHOT pilihan kurir
  P->>J: POST /shipments/create (setelah lunas / COD)
  J-->>P: awb, price, tracking_url
  K->>J: status berubah (pickup, antar, dst.)
  J->>P: POST /webhooks/jubelio (x-jubelio-signature)
  P-->>J: 200 OK (segera)
  Note over P: Verifikasi signature -> dedup -> abaikan event usang -> update order
  P->>J: GET /shipments/awb/{awb} (rekonsiliasi jika webhook hilang)
  B->>P: Lacak pesanan
```

---

## 7. Algoritma & keputusan desain

Setiap poin menunjuk file tempat penerapannya — buka file itu untuk melihat kode dan komentarnya.

### 7.1 Token: cache + *single-flight* — `lib/tokenManager.js`
Token berlaku 24 jam. Disimpan di memori dan diperbarui 60 detik sebelum kedaluwarsa. Bila 50 request datang bersamaan saat token habis, hanya **satu** request `generate-token` yang dikirim; sisanya menunggu `Promise` yang sama. Saat API membalas `401`, token di-invalidate dan request diulang **sekali**.

### 7.2 Klien HTTP: kebijakan retry berbeda untuk GET dan POST — `lib/jubelioClient.js`
- `GET`: aman → retry maks 2× dengan *exponential backoff* (300 ms, 600 ms) untuk error jaringan/timeout/5xx.
- `POST`: **tidak** di-retry otomatis. Timeout pada `POST /shipments/create` berarti *resi mungkin sudah terbit*; mengulang buta bisa menerbitkan **dua resi dan dua tagihan**. Error ditandai `outcomeUnknown = true`.

### 7.3 Berat & dimensi paket — `services/shippingCalc.js`
Satuan kontrak: **berat gram, dimensi cm**.
```
berat volumetrik (kg) = (panjang × lebar × tinggi) / pembagi        (pembagi umum darat: 6000)
berat tertagih        = max(berat aktual, berat volumetrik)
```
Contoh: bantal 500 g berukuran 60×40×20 cm → 48.000/6000 = **8 kg** → ongkir sebagai paket 8 kg. Pembagi **tidak didokumentasikan Jubelio**; Jubelio/kurir yang menghitung tarif sebenarnya. Hitungan lokal hanya estimasi (`VOLUMETRIC_DIVISOR`).
Menggabungkan beberapa barang menjadi satu paket memakai heuristik sederhana: `panjang = max`, `lebar = max`, `tinggi = jumlah(tinggi × qty)` (ditumpuk). Di produksi ganti dengan aturan kemasan nyata.

### 7.4 Ongkir di checkout — `services/rateService.js`
1. Bangun payload: `origin`/`destination` (`area_id`, `zipcode`, `coordinate` bila ada), `package_detail`, `weight` (wajib), `total_value` (untuk asuransi).
2. `POST /rates/all` (semua kurir) atau `POST /rates` + `service_category_id` (satu kategori).
3. Normalisasi, **urutkan termurah**, opsional filter COD (`is_cod_supported`).
4. **Pakai field `rates`, bukan `final_rates`** (ditegaskan kontrak).

### 7.5 Batas kepercayaan (*trust boundary*) — `orderService.resolveQuote`
Browser **tidak boleh** mengirim harga/berat. Pelanggan hanya mengirim `courierId` + `courierServiceId`; server mengambil **ulang** tarif, mencari layanan itu, lalu memakai harganya. Harga, berat, dimensi produk juga dari katalog server. Pilihan kurir disimpan sebagai **snapshot** di order (tarif bisa berubah kapan saja).

### 7.6 Subsidi ongkir milik platform — `rateService.computeBuyerShipping`
```
subsidi   = subtotal ≥ minSubtotal ? min(maxSubsidy, ongkir) : 0
pembeli   = ongkir − subsidi + asuransi(opsional) + biaya COD(opsional)
```
Yang ditagihkan Jubelio ke kamu tetap `ongkir` penuh; selisihnya biaya promosi platform.

### 7.7 Pembuatan resi anti-dobel — `services/shipmentService.js`
```
(belum ada) ──create──▶ CREATING ──sukses─────────▶ CREATED ──cancel──▶ CANCELED
                           ├────gagal jelas───────▶ FAILED   (boleh coba lagi)
                           └────timeout/putus─────▶ UNKNOWN  (DILARANG retry buta)
```
- State `CREATING` disimpan **sebelum** memanggil Jubelio (jejak percobaan) + lock per order.
- `UNKNOWN` diselesaikan manual: operator cek dashboard Jubelio → `POST /api/orders/:id/resolve-unknown` dengan `awb` (resi ada) atau tanpa `awb` (tidak ada → `FAILED`).
- Lock in-memory hanya aman untuk satu proses. Di produksi gunakan **unique partial index** (lihat `docs/skema-database.sql`: `one_active_shipment_per_order`) atau `SELECT … FOR UPDATE`.
- Setelah sukses, `price` riil dari respons dibandingkan dengan snapshot checkout (`priceDrift`) dan disimpan untuk rekonsiliasi tagihan bulanan.

### 7.8 Webhook yang tangguh — `routes/webhooks.js`, `services/webhookService.js`
1. **Raw body**: signature dihitung dari string asli (`app.js` menyimpan `req.rawBody`), bukan `JSON.stringify(req.body)`.
2. **Signature** — `lib/signature.js`: mengikuti *contoh kode* dokumen: `HMAC-SHA256(key = secret, data = payload + secret)` hex, dibandingkan *timing-safe*. (Teks dokumen hanya menyebut "SHA256" — konfirmasi ke Jubelio.)
3. Balas **200 segera**, proses di belakang (`setImmediate`).
4. **Dedup**: kunci `awb|latest_status|tracking.status|tracking.date`; dicatat **setelah** sukses diproses.
5. **Urutan terbalik / usang**: lihat 7.9.
6. Event untuk **AWB yang belum dikenal** tidak ditandai selesai (bisa tiba sebelum respons create resi tersimpan); terkejar oleh rekonsiliasi.

### 7.9 Mesin status pengiriman — `domain/shippingStatus.js`, `services/trackingService.js`
Status Jubelio (`latest_status`): `WAITING → CONFIRMED_BY_COURIER → ON_THE_WAY_PICK_UP → PICKED_UP → ON_DELIVERY → DELIVERED`, ditambah `ON_HOLD`, `SHIPMENT_ISSUE`, `RETURNED`, `CANCELED`.
Update diterapkan hanya jika **lolos semua**: status dikenal · berbeda dari status sekarang · status sekarang **belum final** (`DELIVERED/RETURNED/CANCELED` tidak bisa berubah) · waktu event **tidak lebih lama** dari event terakhir yang diterapkan. Event tetap dicatat di riwayat walau status tidak berubah. `ON_HOLD → ON_DELIVERY` sah (kurir gagal antar lalu mencoba lagi). **Jangan** memakai kode status mentah kurir (F02, S01, D09…) untuk logika bisnis.
Pemetaan ke order: `WAITING/CONFIRMED/ON_THE_WAY_PICK_UP → AWAITING_PICKUP`, `PICKED_UP/ON_DELIVERY → SHIPPED`, `ON_HOLD/SHIPMENT_ISSUE → SHIPMENT_ISSUE`, `DELIVERED`, `RETURNED`, `CANCELED → READY_TO_SHIP` (siap dibuatkan resi baru).

### 7.10 Rekonsiliasi — `shipmentService.reconcileStale`
Webhook bisa hilang. Untuk resi aktif yang lama tidak berubah (`RECONCILE_STALE_AFTER_MINUTES`), tanya langsung `GET /shipments/awb/{awb}` dan terapkan lewat **jalur yang sama** dengan webhook. Aktifkan berkala lewat `RECONCILE_INTERVAL_MINUTES` atau panggil `POST /api/shipping/reconcile`.

### 7.11 Pembatalan — `shipmentService.cancelForOrder`
Guard lokal (hanya status `WAITING/CONFIRMED_BY_COURIER/ON_THE_WAY_PICK_UP`), lalu Jubelio yang memutuskan. Pesan penolakan dipetakan ke pesan ramah: *"the courier do not accept cancellation"* dan *"too close with pickup schedule"*.

---

## 8. Skenario gagal yang bisa kamu coba (mock)

| Skenario | Cara memicu | Perilaku yang diharapkan |
|---|---|---|
| Timeout saat create resi | `POST /__mock/next-create {"mode":"timeout"}` lalu `ship` | state `UNKNOWN`, `ship` ulang ditolak 409, selesaikan via `resolve-unknown` |
| Server error 500 | `{"mode":"error500"}` | state `FAILED`, boleh `ship` ulang |
| Saldo Wallet < Rp50.000 | `POST /__mock/wallet {"balance":10000}` | create gagal, order tetap `READY_TO_SHIP` |
| Token kedaluwarsa | `POST /__mock/expire-tokens` | klien minta token baru otomatis |
| Webhook palsu | `simulate` dengan `"badSignature": true` | ditolak 401, status tidak berubah |
| Webhook dobel / terbalik | `simulate` status yang sama / lebih lama | diabaikan (DUPLICATE / STALE_EVENT) |
| Webhook hilang | `POST /__mock/webhook-url {"url":""}` lalu `simulate` | status tertinggal; terkejar via `reconcile` |
| Kurir tak mengizinkan pembatalan | pilih `SiCepat GOKIL` (13/1326) lalu cancel | 409 dengan pesan ramah |

Semuanya sudah dicakup di `test/flow.test.js` — baca test itu sebagai dokumentasi perilaku.

---

## 9. Dari contoh ini ke platformmu

| Di proyek ini | Ganti di platform sungguhan |
|---|---|
| `store/db.js` in-memory | Database (skema contoh: `docs/skema-database.sql`), transaksi + unique index |
| `data/products.json` | Katalog produk nyata dengan **berat (gram) & dimensi (cm) wajib per SKU** |
| `orderService.markPaid` (simulasi) | Webhook payment gateway |
| Tanpa autentikasi | Login pelanggan, peran admin/gudang untuk `ship`, `cancel`, `resolve-unknown`, `reconcile` |
| Alamat gudang dari `.env` | Tabel gudang (`WAREHOUSE_*` → per gudang) |
| `setImmediate` untuk webhook | Antrian (BullMQ/SQS/dsb.) + *worker* |
| Rekonsiliasi `setInterval` | Job scheduler / cron |
| Lock in-memory | Lock/constraint di database |

**Checklist produksi**
- [ ] Webhook di **HTTPS**, `JUBELIO_WEBHOOK_SECRET` terisi (di `NODE_ENV=production` tanpa secret, webhook ditolak)
- [ ] Rahasia (`client_secret`, webhook secret) di secret manager, bukan di repo (`.env` sudah di `.gitignore`)
- [ ] Unique index satu-shipment-aktif per order; idempotensi sampai level database
- [ ] Alert saldo Wallet (kontrak tidak punya endpoint saldo → pantau lonjakan gagal-create / minta ke Jubelio)
- [ ] Rekonsiliasi harga: bandingkan `shipments.price` dengan faktur bulanan (tgl. 1), siapkan alur dispute
- [ ] Rate-limit & autentikasi untuk endpoint publik; validasi input lebih ketat
- [ ] Log terstruktur + metrik: jumlah `UNKNOWN`, `FAILED`, webhook ditolak/dobel, latensi `/rates/all`
- [ ] Kebijakan data pribadi untuk nama/telepon/alamat pelanggan

---

## 10. Asumsi & batasan yang diketahui

- **Tidak diuji ke Jubelio asli.** Mock = pemahaman atas kontrak, bukan jaminan perilaku asli.
- **Ambigu di kontrak** (ditandai di komentar kode & `docs/PERTANYAAN_UNTUK_JUBELIO.md`): algoritma signature, makna `items[].value` (per unit/total) dan `shipping_insurance` pada create, semantik COD (barang+ongkir atau ongkir saja?) dan apakah create via API langsung memberi resi atau menunggu konfirmasi pelanggan, penjadwalan pickup, apakah `ref_no` boleh diisi nomor order, endpoint label & saldo.
- ID layanan di mock selain contoh kontrak (JNE 11/1101, SiCepat 13/1326–1327, Lion 24/2452) **fiktif**. Ambil ID asli dari respons `/rates/all` akunmu.
- Contoh JSON di dokumen Jubelio beberapa tidak valid (kutip hilang, dsb.); jangan disalin mentah.
- Heuristik dimensi paket dan pembagi volumetrik adalah penyederhanaan.

## 11. Troubleshooting

| Gejala | Penyebab umum |
|---|---|
| `JUBELIO_CREDENTIALS_MISSING` | `.env` belum diisi / belum disalin dari `.env.example` |
| `ECONNREFUSED` ke `:4010` | mock belum jalan → `npm run mock` atau `npm run dev:all` |
| Webhook selalu 401 | secret berbeda antara dashboard/mock dan `.env`; body dimodifikasi sebelum diverifikasi (gunakan raw body) |
| `Layanan kurir tidak tersedia` | `courierId`/`courierServiceId` tidak ada di hasil rates untuk rute & paket itu (atau tidak mendukung COD) |
| `Resi hanya bisa dibuat saat READY_TO_SHIP` | order belum dibayar (`/pay`) |
| Port 3000/4010 terpakai | ubah `PORT` / `MOCK_PORT` |
| `node --watch` tidak dikenali | gunakan Node ≥ 18.11 (disarankan 20+) |

Lisensi: MIT. Proyek ini tidak berafiliasi dengan Jubelio.
