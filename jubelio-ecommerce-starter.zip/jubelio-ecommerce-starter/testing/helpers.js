'use strict';
process.env.LOG_LEVEL = 'silent';
const http = require('node:http');
const { createMockServer } = require('../mock/jubelioMockServer');
const { loadConfig } = require('../src/config/env');
const { createContainer } = require('../src/container');

/** Rakit mock server + container + penerima webhook lokal. Setiap test mendapat set sendiri. */
async function setup({ timeoutMs = 2000, mockOpts = {} } = {}) {
  const mock = createMockServer({ port: 0, webhookUrl: '', ...mockOpts });
  const port = await mock.start();
  const base = `http://127.0.0.1:${port}`;
  const config = loadConfig({
    JUBELIO_BASE_URL: base, JUBELIO_CLIENT_ID: 'mock-client', JUBELIO_CLIENT_SECRET: 'mock-secret',
    JUBELIO_WEBHOOK_SECRET: 'mock-webhook-secret', JUBELIO_TIMEOUT_MS: String(timeoutMs),
  });
  const container = createContainer(config, { sleep: () => Promise.resolve() });

  // Penerima webhook: meniru route /webhooks/jubelio (verify -> handle)
  const results = [];
  const receiver = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      if (!container.webhookService.verify(body, req.headers['x-jubelio-signature'])) {
        results.push({ rejected: true });
        res.writeHead(401); return res.end('{}');
      }
      res.writeHead(200); res.end('{}');
      results.push(container.webhookService.handle(JSON.parse(body)));
    });
  });
  await new Promise((r) => receiver.listen(0, r));
  mock.setWebhookUrl(`http://127.0.0.1:${receiver.address().port}/webhooks/jubelio`);

  const admin = async (path, body) => {
    const r = await fetch(`${base}/__mock${path}`, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    return r.json();
  };
  const teardown = async () => { await mock.stop(); await new Promise((r) => { receiver.closeAllConnections?.(); receiver.close(r); }); };
  return { mock, base, config, container, results, admin, teardown };
}

const customer = { name: 'Budi', phone: '081211112222', address: 'Jl. Penerima No. 5', areaId: '3174011001', zipcode: '12820' };
const JNE_REG = { courierId: 11, courierServiceId: 1101 };
const SICEPAT_GOKIL = { courierId: 13, courierServiceId: 1326 };
const JNT_EZ = { courierId: 15, courierServiceId: 1501 };

/** Order yang sudah dibayar dan siap dibuatkan resi. */
async function readyOrder(container, courier = JNE_REG, extra = {}) {
  const o = await container.orderService.createOrder({ customer, items: [{ sku: 'SKU-KAOS-M', qty: 2 }, { sku: 'SKU-SAMBAL-600', qty: 1 }], courier, ...extra });
  return extra.cod ? o : container.orderService.markPaid(o.id);
}

const tick = (ms = 80) => new Promise((r) => setTimeout(r, ms));

module.exports = { setup, customer, JNE_REG, SICEPAT_GOKIL, JNT_EZ, readyOrder, tick };
