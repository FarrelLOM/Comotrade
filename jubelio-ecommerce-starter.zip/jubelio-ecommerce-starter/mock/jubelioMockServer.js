'use strict';
/**
 * MOCK SERVER Jubelio Shipment (hanya untuk belajar / testing lokal).
 * Meniru bentuk request-response API Contract v1.8. DATA & ID KURIR DI SINI SEBAGIAN FIKTIF
 * (hanya ID yang muncul di contoh kontrak yang asli: JNE 11/1101, SiCepat 13/1326-1327, Lion 24/2452).
 * ID layanan sebenarnya HARUS diambil dari respons /rates/all milik akunmu.
 *
 * Endpoint tambahan khusus mock (prefix /__mock):
 *   POST /__mock/simulate            {awb, status, detail?, badSignature?}  -> kirim 1 webhook
 *   POST /__mock/simulate-lifecycle  {awb, delayMs?}                        -> kirim rangkaian status sampai DELIVERED
 *   POST /__mock/next-create         {mode: "ok"|"timeout"|"error500"}      -> skenario gagal utk create resi berikutnya
 *   POST /__mock/wallet              {balance}                               -> < 50000 => create resi ditolak
 *   POST /__mock/webhook-url         {url}                                   -> ubah tujuan webhook; url kosong = webhook dimatikan
 *   POST /__mock/expire-tokens                                               -> semua token jadi 401 (uji refresh token)
 *   GET  /__mock/state | POST /__mock/reset
 */
const http = require('node:http');
const crypto = require('node:crypto');
const { computeSignature } = require('../src/lib/signature');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const CATEGORIES = [
  { service_category_id: 1, name: 'REGULER' },
  { service_category_id: 2, name: 'EKONOMI' },
  { service_category_id: 3, name: 'NEXTDAY' },
  { service_category_id: 4, name: 'INSTANT' },
  { service_category_id: 5, name: 'SAMEDAY' },
  { service_category_id: 6, name: 'CARGO' },
];

const mkRegion = (area, district, city, province, area_id, zipcode) => ({
  name: `${area}, ${district}, ${city}, ${province}. ${zipcode}`,
  province, city, district, area, area_id, zipcode,
});
const JKT = ['DKI JAKARTA', 'KOTA ADM. JAKARTA SELATAN'];
const REGIONS = [
  mkRegion('Tebet Timur', 'Tebet', JKT[1], JKT[0], '3174011001', '12820'),
  mkRegion('Tebet Barat', 'Tebet', JKT[1], JKT[0], '3174011002', '12810'),
  mkRegion('Menteng Dalam', 'Tebet', JKT[1], JKT[0], '3174011003', '12870'),
  mkRegion('Kebon Baru', 'Tebet', JKT[1], JKT[0], '3174011004', '12830'),
  mkRegion('Bukit Duri', 'Tebet', JKT[1], JKT[0], '3174011005', '12840'),
  mkRegion('Manggarai Selatan', 'Tebet', JKT[1], JKT[0], '3174011006', '12860'),
  mkRegion('Sirnagalih', 'Tamansari', 'KAB. BOGOR', 'JAWA BARAT', '3201312002', '16610'),
  mkRegion('Sukamantri', 'Tamansari', 'KAB. BOGOR', 'JAWA BARAT', '3201312001', '16610'),
];
const PROVINCES = [
  { province_id: '11', name: 'ACEH' }, { province_id: '51', name: 'BALI' },
  { province_id: '36', name: 'BANTEN' }, { province_id: '17', name: 'BENGKULU' },
];
const CITIES = { 11: [{ city_id: '1105', province_id: '11', name: 'KAB. ACEH BARAT' }, { city_id: '1112', province_id: '11', name: 'KAB. ACEH BARAT DAYA' }] };
const DISTRICTS = { 1105: [{ district_id: '110507', city_id: '1105', name: 'Arongan Lambalek' }, { district_id: '110506', city_id: '1105', name: 'Bubon' }] };
const AREAS = { 110507: [
  { area_id: '1105072002', district_id: '110507', name: 'Alue Bagok', zipcode: '22394' },
  { area_id: '1105072004', district_id: '110507', name: 'Alue Batee', zipcode: '22394' },
] };

// base = tarif kg pertama, perKg = tambahan tiap kg berikutnya
const SERVICES = [
  { courier_id: 11, courier_name: 'JNE', id: 1101, code: 'REG', name: 'JNE REG', category: 'REGULER', catId: 1, base: 9000, perKg: 8000, eta: [2, 3], cod: false, cancel: true },
  { courier_id: 11, courier_name: 'JNE', id: 1102, code: 'YES', name: 'JNE YES', category: 'NEXTDAY', catId: 3, base: 20000, perKg: 12000, eta: [1, 1], cod: false, cancel: true },
  { courier_id: 13, courier_name: 'Si Cepat', id: 1327, code: 'REG', name: 'SiCepat REG', category: 'REGULER', catId: 1, base: 8000, perKg: 7500, eta: [2, 3], cod: false, cancel: true },
  { courier_id: 13, courier_name: 'Si Cepat', id: 1326, code: 'GOKIL', name: 'SiCepat GOKIL', category: 'CARGO', catId: 6, base: 30000, perKg: 4000, eta: [3, 5], cod: false, cancel: false },
  { courier_id: 24, courier_name: 'Lion Parcel', id: 2452, code: 'REGPACK', name: 'Lion Parcel REGPACK', category: 'REGULER', catId: 1, base: 9500, perKg: 7000, eta: [2, 4], cod: false, cancel: true },
  { courier_id: 15, courier_name: 'J&T Express', id: 1501, code: 'EZ', name: 'J&T EZ', category: 'REGULER', catId: 1, base: 8500, perKg: 7800, eta: [2, 3], cod: true, cancel: true },
  { courier_id: 15, courier_name: 'J&T Express', id: 1502, code: 'ECO', name: 'J&T ECONOMY', category: 'EKONOMI', catId: 2, base: 6500, perKg: 6000, eta: [4, 6], cod: true, cancel: true },
];

const COURIER_CODE = {
  WAITING: ['W00', 'SHIPMENT CREATED'],
  CONFIRMED_BY_COURIER: ['C01', 'CONFIRMED BY COURIER'],
  ON_THE_WAY_PICK_UP: ['P01', 'COURIER ON THE WAY TO PICK UP'],
  PICKED_UP: ['S01', 'SUCCESS PICKUP'],
  ON_DELIVERY: ['IP3', 'WITH DELIVERY COURIER'],
  ON_HOLD: ['F02', 'DELIVERY FAILURE - RECEIVER NOT AT HOME'],
  DELIVERED: ['D09', 'DELIVERED'],
  RETURNED: ['R01', 'RETURNED TO SENDER'],
  CANCELED: ['CNCL', 'CANCELED'],
  SHIPMENT_ISSUE: ['X01', 'SHIPMENT ISSUE'],
};
const LIFECYCLE = ['CONFIRMED_BY_COURIER', 'ON_THE_WAY_PICK_UP', 'PICKED_UP', 'ON_DELIVERY', 'DELIVERED'];
const CANCELABLE = new Set(['WAITING', 'CONFIRMED_BY_COURIER', 'ON_THE_WAY_PICK_UP']);

function createMockServer(opts = {}) {
  const o = {
    port: 4010,
    webhookUrl: 'http://localhost:3000/webhooks/jubelio',
    webhookSecret: 'mock-webhook-secret',
    clientId: 'mock-client',
    clientSecret: 'mock-secret',
    walletBalance: 1_000_000,
    timeoutDelayMs: 20_000,
    ...opts,
  };
  const fresh = () => ({ tokens: new Set(), shipments: new Map(), seq: 1000, tokenSeq: 0, nextCreateMode: 'ok', walletBalance: o.walletBalance });
  let state = fresh();

  // ---------- util HTTP ----------
  const send = (res, status, body) => {
    if (res.writableEnded || res.destroyed) return;
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(body));
  };
  const httpErr = (status, message) => Object.assign(new Error(message), { status });
  const readJson = (req) => new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const t = Buffer.concat(chunks).toString('utf8');
      if (!t) return resolve({});
      try { resolve(JSON.parse(t)); } catch { reject(httpErr(400, 'invalid JSON body')); }
    });
    req.on('error', reject);
  });
  const authOk = (req) => {
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    return Boolean(m && state.tokens.has(m[1]));
  };

  // ---------- logika bisnis palsu ----------
  const iso = (offsetDays = 0) => new Date(Date.now() + offsetDays * 86_400_000).toISOString();

  function chargeableKg({ weight, package_detail: pd, items }) {
    let vol = 0;
    if (pd && pd.length && pd.width && pd.height) vol = ((pd.length * pd.width * pd.height) / 6000) * 1000;
    else if (Array.isArray(items)) vol = items.reduce((s, i) => s + (((i.length * i.width * i.height) / 6000) * 1000) * (i.quantity || 1), 0);
    return Math.max(1, Math.ceil(Math.max(Number(weight) || 0, vol) / 1000));
  }
  const priceOf = (svc, kg) => svc.base + svc.perKg * (kg - 1);

  function computeRates(body, categoryId) {
    const bad = [];
    if (!body.origin || !body.origin.zipcode) bad.push('origin.zipcode is required');
    if (!body.destination || !body.destination.zipcode) bad.push('destination.zipcode is required');
    if (!(Number(body.weight) > 0)) bad.push('weight is required');
    if (bad.length) throw httpErr(400, bad.join('; '));
    const kg = chargeableKg(body);
    const value = Number(body.total_value) || 0;
    return SERVICES.filter((s) => !categoryId || s.catId === Number(categoryId)).map((s) => {
      const rates = priceOf(s, kg);
      return {
        courier_id: s.courier_id, courier_name: s.courier_name, rates,
        courier_service_id: s.id, courier_service_code: s.code, courier_service_name: s.name,
        courier_service_category: s.category,
        eta_from: iso(s.eta[0]), eta_to: iso(s.eta[1]),
        is_cod_supported: s.cod, courier_logo: '',
        shipping_insurance: Math.max(100, Math.round(value * 0.003)),
        cod_fee: s.cod ? Math.max(2500, Math.round(value * 0.02)) : null,
        discount_rates: 0, final_rates: rates, promotion: null,
      };
    });
  }

  function validateCreate(b) {
    const e = [];
    if (!b.courier_id) e.push('courier_id is required');
    if (!b.courier_service_id) e.push('courier_service_id is required');
    if (!b.ref_no) e.push('ref_no is required');
    for (const side of ['origin', 'destination']) {
      const p = b[side];
      if (!p) { e.push(`${side} is required`); continue; }
      for (const f of ['name', 'phone', 'address', 'zipcode']) if (!p[f]) e.push(`${side}.${f} is required`);
    }
    if (!Array.isArray(b.items) || !b.items.length) e.push('items is required');
    else b.items.forEach((it, i) => {
      for (const f of ['item_name', 'quantity', 'value', 'weight', 'length', 'width', 'height']) {
        if (it[f] === undefined || it[f] === null) e.push(`items[${i}].${f} is required`);
      }
    });
    return e;
  }

  function addTracking(sh, status, detail) {
    const [code, defaultDetail] = COURIER_CODE[status];
    const entry = { date: new Date().toISOString(), status: code, status_detail: detail || defaultDetail };
    sh.tracking.push(entry);
    sh.latest_status = status;
    return entry;
  }

  async function postWebhook(sh, entry, { badSignature = false } = {}) {
    if (!o.webhookUrl) return { skipped: true };
    const payload = {
      event: 'awb', ref_no: sh.ref_no, awb: sh.awb, shipment_id: sh.shipment_id, latest_status: sh.latest_status,
      courier: {
        courier_id: sh.svc.courier_id, courier_service_id: sh.svc.id, courier_name: sh.svc.courier_name,
        courier_service_name: sh.svc.name, service_category_name: sh.svc.category,
      },
      delivered_img_url: sh.latest_status === 'DELIVERED' ? 'https://example.com/mock-pod.jpg' : null,
      sign_img_url: null, live_tracking_url: null, tracking_url: sh.tracking_url,
      pod_url: sh.latest_status === 'DELIVERED' ? 'https://example.com/mock-pod.pdf' : null,
      tracking: entry,
    };
    const body = JSON.stringify(payload); // string INI yang ditandatangani & dikirim persis
    const signature = badSignature ? 'deadbeef' : computeSignature(body, o.webhookSecret);
    try {
      const r = await fetch(o.webhookUrl, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-jubelio-signature': signature }, body,
        signal: AbortSignal.timeout(5000),
      });
      return { webhookHttpStatus: r.status };
    } catch (e) {
      return { webhookError: e.message };
    }
  }

  const detailOf = (sh) => ({
    shipment_id: sh.shipment_id, ref_no: sh.ref_no, tracking_url_id: sh.awb, awb: sh.awb,
    awb_generated_date: sh.created, courier_id: sh.svc.courier_id, courier_name: sh.svc.courier_name,
    courier_service_id: sh.svc.id, courier_service_name: sh.svc.name,
    service_category_id: sh.svc.catId, service_category_name: sh.svc.category,
    price: sh.price, price_bill: sh.price, is_insurance: Boolean(sh.body.shipping_insurance),
    latest_status: sh.latest_status,
    origin_name: sh.body.origin.name, origin_phone: sh.body.origin.phone, origin_address: sh.body.origin.address, origin_zipcode: sh.body.origin.zipcode,
    destination_name: sh.body.destination.name, destination_phone: sh.body.destination.phone,
    destination_address: sh.body.destination.address, destination_zipcode: sh.body.destination.zipcode,
    is_cod: Boolean(sh.body.is_cod), cod_fee: 0, shipping_insurance: sh.body.shipping_insurance || 0,
    delivered_img_url: sh.latest_status === 'DELIVERED' ? 'https://example.com/mock-pod.jpg' : null,
    items: sh.body.items, tracking: sh.tracking,
    eta: `${iso(sh.svc.eta[0]).slice(0, 10)} - ${iso(sh.svc.eta[1]).slice(0, 10)}`,
    live_tracking_url: null, tracking_url: sh.tracking_url,
  });

  // ---------- router ----------
  async function handle(req, res) {
    const url = new URL(req.url, 'http://mock');
    const p = url.pathname;
    const m = req.method;

    // --- auth ---
    if (m === 'POST' && p === '/auth/generate-token') {
      const b = await readJson(req);
      if (b.client_id !== o.clientId || b.client_secret !== o.clientSecret) {
        return send(res, 500, { statusCode: 500, error: 'Internal Server Error', message: 'An internal server error occurred' });
      }
      const token = `mock-token-${++state.tokenSeq}-${crypto.randomBytes(6).toString('hex')}`;
      state.tokens.add(token);
      return send(res, 200, { token, expires_in: 86400 });
    }

    // --- endpoint khusus mock ---
    if (p.startsWith('/__mock/')) return mockAdmin(req, res, p, m);

    // --- referensi (di kontrak tidak mewajibkan token) ---
    if (m === 'GET' && p === '/services/categories') return send(res, 200, CATEGORIES);
    if (m === 'GET' && p === '/regions') {
      const q = (url.searchParams.get('name') || '').toLowerCase();
      return send(res, 200, q ? REGIONS.filter((r) => r.name.toLowerCase().includes(q)) : REGIONS);
    }
    if (m === 'GET' && p === '/region/provinces') return send(res, 200, PROVINCES);
    let mm;
    if (m === 'GET' && (mm = /^\/region\/cities\/([^/]+)$/.exec(p))) return send(res, 200, CITIES[mm[1]] || []);
    if (m === 'GET' && (mm = /^\/region\/districts\/([^/]+)$/.exec(p))) return send(res, 200, DISTRICTS[mm[1]] || []);
    if (m === 'GET' && (mm = /^\/region\/areas\/([^/]+)$/.exec(p))) return send(res, 200, AREAS[mm[1]] || []);

    // --- butuh token ---
    if (!authOk(req)) return send(res, 401, { statusCode: 401, error: 'Unauthorized', message: 'invalid or expired token' });

    if (m === 'POST' && p === '/rates') {
      const b = await readJson(req);
      if (!b.service_category_id) throw httpErr(400, 'service_category_id is required');
      return send(res, 200, computeRates(b, b.service_category_id));
    }
    if (m === 'POST' && p === '/rates/all') return send(res, 200, computeRates(await readJson(req), null));

    if (m === 'POST' && p === '/shipments/create') return createShipment(req, res);
    if (m === 'POST' && p === '/shipments/cancel') return cancelShipment(req, res);
    if (m === 'GET' && (mm = /^\/shipments\/awb\/([^/]+)$/.exec(p))) {
      const sh = state.shipments.get(decodeURIComponent(mm[1]));
      if (!sh) return send(res, 500, { statusCode: 500, error: 'Internal Server Error', message: 'shipment not found (mock)' });
      return send(res, 200, detailOf(sh));
    }
    return send(res, 404, { statusCode: 404, error: 'Not Found', message: `${m} ${p}` });
  }

  async function createShipment(req, res) {
    const body = await readJson(req);
    const mode = state.nextCreateMode;
    state.nextCreateMode = 'ok';
    if (mode === 'error500') return send(res, 500, { statusCode: 500, error: 'Internal Server Error', message: 'An internal server error occurred' });

    const errs = validateCreate(body);
    if (errs.length) throw httpErr(400, errs.join('; '));
    if (state.walletBalance < 50_000) {
      return send(res, 500, { statusCode: 500, error: 'Internal Server Error', message: 'insufficient Jubelio Wallet balance (mock; saldo minimal Rp50.000)' });
    }
    const svc = SERVICES.find((s) => s.courier_id === Number(body.courier_id) && s.id === Number(body.courier_service_id));
    if (!svc) throw httpErr(400, 'unknown courier_id / courier_service_id');

    const weight = body.items.reduce((s, i) => s + i.weight * (i.quantity || 1), 0);
    const kg = chargeableKg({ weight, package_detail: body.package_detail, items: body.items });
    const shipment_id = ++state.seq;
    const awb = `MOCK${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const sh = {
      shipment_id, awb, svc, body, price: priceOf(svc, kg),
      ref_no: `SH-${String(shipment_id).padStart(9, '0')}`, created: new Date().toISOString(),
      tracking_url: `https://example.com/track/${awb}`, latest_status: 'WAITING', tracking: [],
    };
    addTracking(sh, 'WAITING');
    state.shipments.set(awb, sh); // efek samping TERJADI walau nanti response-nya timeout

    if (mode === 'timeout') await sleep(o.timeoutDelayMs);
    return send(res, 200, { shipment_id, awb, tracking_url: sh.tracking_url, price: sh.price, extra_info: {} });
  }

  async function cancelShipment(req, res) {
    const b = await readJson(req);
    if (!b.awb_code || !b.cancel_reason) throw httpErr(400, 'awb_code and cancel_reason are required');
    const sh = state.shipments.get(b.awb_code);
    if (!sh) return send(res, 500, { statusCode: 500, error: 'cancel awb is failed', message: 'awb not found (mock)' });
    if (!sh.svc.cancel) return send(res, 500, { statusCode: 500, error: 'cancel awb is failed', message: 'the courier do not accept cancellation' });
    if (!CANCELABLE.has(sh.latest_status)) return send(res, 500, { statusCode: 500, error: 'cancel awb is failed', message: 'too close with pickup schedule' });
    const entry = addTracking(sh, 'CANCELED', b.cancel_reason);
    send(res, 200, { status: 'cancel successful', awb_code: sh.awb, courier_name: sh.svc.courier_name, ref_no: sh.ref_no });
    setTimeout(() => postWebhook(sh, entry), 100); // Jubelio juga mengirim webhook CANCELED
  }

  async function mockAdmin(req, res, p, m) {
    const b = m === 'POST' ? await readJson(req) : {};
    if (p === '/__mock/state') {
      return send(res, 200, { walletBalance: state.walletBalance, nextCreateMode: state.nextCreateMode, activeTokens: state.tokens.size,
        shipments: [...state.shipments.values()].map((s) => ({ awb: s.awb, status: s.latest_status, service: s.svc.name })) });
    }
    if (p === '/__mock/webhook-url') { o.webhookUrl = b.url || ''; return send(res, 200, { webhookUrl: o.webhookUrl || '(nonaktif)' }); }
    if (p === '/__mock/reset') { state = fresh(); return send(res, 200, { ok: true }); }
    if (p === '/__mock/wallet') { state.walletBalance = Number(b.balance); return send(res, 200, { walletBalance: state.walletBalance }); }
    if (p === '/__mock/expire-tokens') { state.tokens.clear(); return send(res, 200, { ok: true }); }
    if (p === '/__mock/next-create') {
      if (!['ok', 'timeout', 'error500'].includes(b.mode)) throw httpErr(400, 'mode must be ok|timeout|error500');
      state.nextCreateMode = b.mode;
      return send(res, 200, { nextCreateMode: b.mode });
    }
    if (p === '/__mock/simulate' || p === '/__mock/simulate-lifecycle') {
      const sh = state.shipments.get(b.awb);
      if (!sh) throw httpErr(404, 'awb not found');
      if (p === '/__mock/simulate') {
        if (!COURIER_CODE[b.status]) throw httpErr(400, `status must be one of ${Object.keys(COURIER_CODE).join(', ')}`);
        const entry = addTracking(sh, b.status, b.detail);
        return send(res, 200, { awb: sh.awb, latest_status: sh.latest_status, ...(await postWebhook(sh, entry, { badSignature: Boolean(b.badSignature) })) });
      }
      const results = [];
      for (const status of LIFECYCLE) {
        const entry = addTracking(sh, status);
        results.push({ status, ...(await postWebhook(sh, entry)) });
        await sleep(Number(b.delayMs) || 300);
      }
      return send(res, 200, { awb: sh.awb, results });
    }
    return send(res, 404, { error: 'unknown mock endpoint' });
  }

  const server = http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      if (err.status) return send(res, err.status, { statusCode: err.status, error: 'Bad Request', message: err.message });
      console.error('[mock] error', err);
      return send(res, 500, { statusCode: 500, error: 'Internal Server Error', message: 'An internal server error occurred' });
    });
  });

  return {
    server,
    get state() { return state; },
    setWebhookUrl: (u) => { o.webhookUrl = u; },
    start: () => new Promise((resolve) => server.listen(o.port, () => resolve(server.address().port))),
    stop: () => new Promise((resolve) => { if (server.closeAllConnections) server.closeAllConnections(); server.close(() => resolve()); }),
  };
}

module.exports = { createMockServer };

if (require.main === module) {
  const env = process.env;
  const mock = createMockServer({
    port: Number(env.MOCK_PORT) || 4010,
    webhookUrl: env.MOCK_WEBHOOK_URL !== undefined ? env.MOCK_WEBHOOK_URL : 'http://localhost:3000/webhooks/jubelio',
    webhookSecret: env.JUBELIO_WEBHOOK_SECRET || 'mock-webhook-secret',
    clientId: env.JUBELIO_CLIENT_ID || 'mock-client',
    clientSecret: env.JUBELIO_CLIENT_SECRET || 'mock-secret',
  });
  mock.start().then((port) => {
    console.log(`Jubelio MOCK server di http://localhost:${port}  (DATA PALSU - hanya untuk belajar)`);
    console.log('kredensial: mock-client / mock-secret | webhook secret: mock-webhook-secret');
  });
}
