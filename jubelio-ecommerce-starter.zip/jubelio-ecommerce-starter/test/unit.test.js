'use strict';
process.env.LOG_LEVEL = 'silent';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const { computeSignature, verifySignature } = require('../src/lib/signature');
const { volumetricWeightGram, chargeableWeightGram, buildPackage } = require('../src/services/shippingCalc');
const { shouldApplyUpdate, toOrderStatus, isCancelable } = require('../src/domain/shippingStatus');
const { TokenManager } = require('../src/lib/tokenManager');
const { loadConfig } = require('../src/config/env');
const { createRateService } = require('../src/services/rateService');

test('signature: sama dengan contoh kode di API Contract (HMAC-SHA256 dari payload+secret)', () => {
  const secret = '123';
  const payload = '{"event":"Resi","awb":5495}';
  const expected = crypto.createHmac('sha256', secret).update(payload + secret).digest('hex');
  assert.equal(computeSignature(payload, secret), expected);
  assert.equal(verifySignature(payload, expected, secret), true);
});

test('signature: menolak payload diubah, header kosong, atau panjang berbeda', () => {
  const sig = computeSignature('{"a":1}', 's');
  assert.equal(verifySignature('{"a":2}', sig, 's'), false);
  assert.equal(verifySignature('{"a":1}', '', 's'), false);
  assert.equal(verifySignature('{"a":1}', 'abc', 's'), false);
  assert.equal(verifySignature('{"a":1}', sig, ''), false);
});

test('shippingCalc: berat volumetrik & berat tertagih', () => {
  // 60 x 40 x 20 = 48.000 cm3 / 6000 = 8 kg
  assert.equal(volumetricWeightGram({ length: 60, width: 40, height: 20 }), 8000);
  assert.equal(chargeableWeightGram({ weight: 500, length: 60, width: 40, height: 20 }), 8000); // bantal: ringan tapi besar
  assert.equal(chargeableWeightGram({ weight: 9000, length: 10, width: 10, height: 10 }), 9000); // berat aktual menang
});

test('shippingCalc: buildPackage menjumlah berat/nilai dan menumpuk tinggi', () => {
  const pkg = buildPackage([
    { sku: 'A', price: 75000, quantity: 2, weightGram: 200, lengthCm: 30, widthCm: 25, heightCm: 3 },
    { sku: 'B', price: 25000, quantity: 1, weightGram: 750, lengthCm: 8, widthCm: 8, heightCm: 22 },
  ]);
  assert.equal(pkg.totalWeightGram, 1150);
  assert.equal(pkg.totalValue, 175000);
  assert.deepEqual(pkg.packageDetail, { length: 30, width: 25, height: 28, weight: 1150 });
});

test('shippingCalc: item tidak lengkap ditolak', () => {
  assert.throws(() => buildPackage([{ sku: 'X', quantity: 1, weightGram: 0, lengthCm: 1, widthCm: 1, heightCm: 1 }]), /weightGram/);
  assert.throws(() => buildPackage([]), /Item/);
});

test('status: webhook dobel, terbalik, dan status final', () => {
  const t1 = '2026-01-01T10:00:00Z';
  const t2 = '2026-01-01T12:00:00Z';
  assert.equal(shouldApplyUpdate({ currentStatus: 'WAITING', currentEventAt: null, incomingStatus: 'PICKED_UP', incomingEventAt: t1 }).apply, true);
  assert.equal(shouldApplyUpdate({ currentStatus: 'PICKED_UP', currentEventAt: t1, incomingStatus: 'PICKED_UP', incomingEventAt: t2 }).reason, 'SAME_STATUS');
  assert.equal(shouldApplyUpdate({ currentStatus: 'ON_DELIVERY', currentEventAt: t2, incomingStatus: 'PICKED_UP', incomingEventAt: t1 }).reason, 'STALE_EVENT');
  assert.equal(shouldApplyUpdate({ currentStatus: 'DELIVERED', currentEventAt: t1, incomingStatus: 'ON_DELIVERY', incomingEventAt: t2 }).reason, 'ALREADY_TERMINAL');
  assert.equal(shouldApplyUpdate({ currentStatus: 'WAITING', incomingStatus: 'NGAWUR' }).reason, 'UNKNOWN_STATUS');
  // ON_HOLD lalu lanjut lagi ON_DELIVERY itu sah (kurir gagal antar lalu coba lagi)
  assert.equal(shouldApplyUpdate({ currentStatus: 'ON_HOLD', currentEventAt: t1, incomingStatus: 'ON_DELIVERY', incomingEventAt: t2 }).apply, true);
});

test('status: pemetaan ke status order & aturan pembatalan', () => {
  assert.equal(toOrderStatus('ON_DELIVERY'), 'SHIPPED');
  assert.equal(toOrderStatus('CANCELED'), 'READY_TO_SHIP');
  assert.equal(toOrderStatus('DELIVERED'), 'DELIVERED');
  assert.equal(isCancelable('ON_THE_WAY_PICK_UP'), true);
  assert.equal(isCancelable('PICKED_UP'), false);
});

function fakeFetch(handler) {
  const fn = async (url, init) => {
    fn.calls += 1;
    const { status = 200, body } = await handler(url, init, fn.calls);
    return { ok: status >= 200 && status < 300, status, text: async () => JSON.stringify(body) };
  };
  fn.calls = 0;
  return fn;
}

test('tokenManager: single-flight (5 request bersamaan = 1 panggilan generate-token)', async () => {
  const f = fakeFetch(async () => ({ body: { token: 'T1', expires_in: 86400 } }));
  const tm = new TokenManager({ baseUrl: 'http://x', clientId: 'a', clientSecret: 'b', fetchImpl: f });
  const tokens = await Promise.all([1, 2, 3, 4, 5].map(() => tm.getToken()));
  assert.deepEqual(new Set(tokens), new Set(['T1']));
  assert.equal(f.calls, 1);
  await tm.getToken(); // masih di-cache
  assert.equal(f.calls, 1);
});

test('tokenManager: diperbarui menjelang kedaluwarsa & setelah invalidate', async () => {
  let clock = 0;
  const f = fakeFetch(async (_u, _i, n) => ({ body: { token: `T${n}`, expires_in: 100 } }));
  const tm = new TokenManager({ baseUrl: 'http://x', clientId: 'a', clientSecret: 'b', fetchImpl: f, now: () => clock, safetyMarginMs: 10_000 });
  assert.equal(await tm.getToken(), 'T1');
  clock = 80_000; // < 100s - 10s margin -> masih valid
  assert.equal(await tm.getToken(), 'T1');
  clock = 95_000; // masuk margin -> refresh
  assert.equal(await tm.getToken(), 'T2');
  tm.invalidate();
  assert.equal(await tm.getToken(), 'T3');
});

test('tokenManager: kredensial kosong / ditolak -> error jelas', async () => {
  const tm = new TokenManager({ baseUrl: 'http://x', clientId: '', clientSecret: '' });
  await assert.rejects(() => tm.getToken(), { code: 'JUBELIO_CREDENTIALS_MISSING' });
  const f = fakeFetch(async () => ({ status: 500, body: { statusCode: 500, error: 'Internal Server Error' } }));
  const tm2 = new TokenManager({ baseUrl: 'http://x', clientId: 'a', clientSecret: 'b', fetchImpl: f });
  await assert.rejects(() => tm2.getToken(), { code: 'JUBELIO_ERROR' });
});

test('rateService: payload memakai package_detail + weight, dan subsidi ongkir dibatasi', () => {
  const config = loadConfig({});
  const rs = createRateService({ client: {}, config });
  const pkg = buildPackage([{ sku: 'A', price: 100000, quantity: 1, weightGram: 1000, lengthCm: 10, widthCm: 10, heightCm: 10 }]);
  const payload = rs.buildRatesPayload({ origin: config.warehouse, destination: { areaId: '3175101006', zipcode: '17425' }, pkg });
  assert.equal(payload.weight, 1000);
  assert.equal(payload.total_value, 100000);
  assert.equal(payload.origin.zipcode, '12920');
  assert.equal(payload.destination.coordinate, undefined); // koordinat kosong tidak dikirim
  assert.equal(payload.service_category_id, undefined);

  const quote = { price: 30000, insurance: 500, codFee: 3000 };
  assert.deepEqual(rs.computeBuyerShipping(quote, { subtotal: 100000 }), { carrierPrice: 30000, subsidy: 0, insurance: 0, codFee: 0, buyerPays: 30000 });
  // subtotal >= 200.000 -> subsidi maksimal 20.000
  assert.equal(rs.computeBuyerShipping(quote, { subtotal: 250000 }).buyerPays, 10000);
  // ongkir lebih kecil dari batas subsidi -> gratis
  assert.equal(rs.computeBuyerShipping({ price: 9000, insurance: 0, codFee: 0 }, { subtotal: 250000 }).buyerPays, 0);
  assert.equal(rs.computeBuyerShipping(quote, { subtotal: 100000, withInsurance: true, cod: true }).buyerPays, 33500);
});
