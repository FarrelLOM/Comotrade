'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { setup, customer, JNE_REG, SICEPAT_GOKIL, JNT_EZ, readyOrder, tick } = require('../testing/helpers');

test('ongkir: /rates/all dinormalisasi, diurutkan termurah, filter COD', async () => {
  const t = await setup();
  try {
    const items = [{ sku: 'SKU-KAOS-M', quantity: 1, price: 75000, weightGram: 200, lengthCm: 30, widthCm: 25, heightCm: 3 }];
    const { quotes, package: pkg } = await t.container.rateService.getQuotes({ destination: { areaId: '3174011001', zipcode: '12820' }, items });
    assert.equal(pkg.totalWeightGram, 200);
    assert.ok(quotes.length >= 5);
    assert.deepEqual(quotes.map((q) => q.price), [...quotes.map((q) => q.price)].sort((a, b) => a - b));
    assert.ok(quotes[0].etaDays.min >= 1);

    const cod = await t.container.rateService.getQuotes({ destination: { zipcode: '12820' }, items, cod: true });
    assert.ok(cod.quotes.length > 0 && cod.quotes.every((q) => q.codSupported && q.courierName === 'J&T Express'));

    const cargo = await t.container.rateService.getQuotes({ destination: { zipcode: '12820' }, items, serviceCategoryId: 6 });
    assert.deepEqual(cargo.quotes.map((q) => q.category), ['CARGO']);
  } finally { await t.teardown(); }
});

test('berat volumetrik memengaruhi tarif (bantal ringan tapi besar)', async () => {
  const t = await setup();
  try {
    const dest = { zipcode: '12820' };
    const bantal = t.container.catalog.find((p) => p.sku === 'SKU-BANTAL');
    const kaos = t.container.catalog.find((p) => p.sku === 'SKU-KAOS-M');
    const a = await t.container.rateService.getQuotes({ destination: dest, items: [{ ...bantal, quantity: 1 }] });
    const b = await t.container.rateService.getQuotes({ destination: dest, items: [{ ...kaos, quantity: 1 }] });
    const pick = (r) => r.quotes.find((q) => q.serviceId === 1101).price;
    assert.ok(pick(a) > pick(b), 'bantal 500 g tapi 60x40x20 cm harus lebih mahal dari kaos 200 g');
  } finally { await t.teardown(); }
});

test('alur lengkap: order -> bayar -> resi -> webhook -> DELIVERED', async () => {
  const t = await setup();
  try {
    const order = await readyOrder(t.container);
    assert.equal(order.status, 'READY_TO_SHIP');
    assert.equal(order.shipping.carrierPrice, order.shipping.price);

    const shipped = await t.container.shipmentService.createForOrder(order.id);
    assert.equal(shipped.status, 'AWAITING_PICKUP');
    assert.equal(shipped.shipment.state, 'CREATED');
    assert.match(shipped.shipment.awb, /^MOCK/);
    assert.equal(shipped.shipment.priceDrift, 0, 'harga resi harus sama dengan snapshot checkout');

    // ganda: create kedua ditolak
    await assert.rejects(() => t.container.shipmentService.createForOrder(order.id), { code: 'CONFLICT' });

    // mock mengirim webhook bertanda tangan -> penerima memverifikasi & memproses
    const awb = shipped.shipment.awb;
    const r = await t.admin('/simulate-lifecycle', { awb, delayMs: 10 });
    assert.equal(r.results.length, 5);
    assert.ok(r.results.every((x) => x.webhookHttpStatus === 200));
    await tick();

    const final = t.container.orderService.getOrder(order.id);
    assert.equal(final.status, 'DELIVERED');
    assert.equal(final.shipment.status, 'DELIVERED');
    assert.equal(final.shipment.deliveredImgUrl, 'https://example.com/mock-pod.jpg');
    assert.equal(final.shipment.events.length, 5, 'lima event lifecycle tercatat berurutan');
    assert.deepEqual(final.shipment.events.map((e) => e.status), ['C01', 'P01', 'S01', 'IP3', 'D09']);

    // data langsung dari Jubelio konsisten dengan data tersimpan
    const live = await t.container.shipmentService.getLiveDetail(order.id);
    assert.equal(live.latest_status, 'DELIVERED');
  } finally { await t.teardown(); }
});

test('webhook: signature salah ditolak, duplikat & event usang diabaikan', async () => {
  const t = await setup();
  try {
    const order = await readyOrder(t.container);
    const { shipment } = await t.container.shipmentService.createForOrder(order.id);

    const bad = await t.admin('/simulate', { awb: shipment.awb, status: 'PICKED_UP', badSignature: true });
    assert.equal(bad.webhookHttpStatus, 401);
    assert.equal(t.container.orderService.getOrder(order.id).shipment.status, 'WAITING', 'webhook tak sah tidak boleh mengubah status');

    await t.admin('/simulate', { awb: shipment.awb, status: 'DELIVERED' });
    await tick();
    assert.equal(t.container.orderService.getOrder(order.id).status, 'DELIVERED');

    // payload yang SAMA persis dikirim ulang -> DUPLICATE
    const sh = t.container.orderService.getOrder(order.id).shipment;
    const last = sh.events[sh.events.length - 1];
    const dup = t.container.webhookService.handle({ event: 'awb', awb: shipment.awb, latest_status: 'DELIVERED', tracking: { date: last.date, status: last.status, status_detail: last.detail } });
    assert.equal(dup.reason, 'DUPLICATE');

    // event ON_DELIVERY datang TERLAMBAT setelah DELIVERED -> status tidak mundur
    await t.admin('/simulate', { awb: shipment.awb, status: 'ON_DELIVERY' });
    await tick();
    assert.equal(t.container.orderService.getOrder(order.id).status, 'DELIVERED');
  } finally { await t.teardown(); }
});

test('timeout saat create resi -> state UNKNOWN, tidak boleh dobel, bisa diselesaikan manual', async () => {
  const t = await setup({ timeoutMs: 300, mockOpts: { timeoutDelayMs: 1200 } });
  try {
    const order = await readyOrder(t.container);
    await t.admin('/next-create', { mode: 'timeout' });

    await assert.rejects(() => t.container.shipmentService.createForOrder(order.id), (e) => e.code === 'JUBELIO_TIMEOUT' && e.outcomeUnknown === true);
    let cur = t.container.orderService.getOrder(order.id);
    assert.equal(cur.shipment.state, 'UNKNOWN');
    assert.equal(cur.status, 'READY_TO_SHIP');

    // percobaan kedua DITOLAK (kalau tidak, bisa terbit dua resi & dua tagihan)
    await assert.rejects(() => t.container.shipmentService.createForOrder(order.id), (e) => e.code === 'CONFLICT' && /UNKNOWN/.test(e.message));

    // ternyata resi memang terbit di sisi Jubelio (efek samping mock terjadi sebelum jeda)
    const state = await t.admin('/state');
    assert.equal(state.shipments.length, 1);
    const awb = state.shipments[0].awb;

    cur = await t.container.shipmentService.resolveUnknown(order.id, { awb });
    assert.equal(cur.shipment.state, 'CREATED');
    assert.equal(cur.shipment.awb, awb);
    assert.equal(cur.status, 'AWAITING_PICKUP');
    assert.equal(t.container.store.findOrderIdByAwb(awb), order.id);
  } finally { await t.teardown(); }
});

test('UNKNOWN tanpa resi di Jubelio -> operator tandai FAILED, lalu boleh coba lagi', async () => {
  const t = await setup({ timeoutMs: 300, mockOpts: { timeoutDelayMs: 800 } });
  try {
    const order = await readyOrder(t.container);
    await t.admin('/next-create', { mode: 'timeout' });
    await assert.rejects(() => t.container.shipmentService.createForOrder(order.id));
    await t.container.shipmentService.resolveUnknown(order.id, {}); // operator: tidak ada resi
    assert.equal(t.container.orderService.getOrder(order.id).shipment.state, 'FAILED');
    // (di mock resi pertama tetap ada; di dunia nyata operator memastikan lewat dashboard)
    const again = await t.container.shipmentService.createForOrder(order.id);
    assert.equal(again.shipment.state, 'CREATED');
    assert.equal(again.shipment.attempts, 2);
  } finally { await t.teardown(); }
});

test('saldo wallet < Rp50.000 -> create gagal jelas (FAILED) dan bisa diulang setelah top up', async () => {
  const t = await setup();
  try {
    const order = await readyOrder(t.container);
    await t.admin('/wallet', { balance: 10000 });
    await assert.rejects(() => t.container.shipmentService.createForOrder(order.id), (e) => e.code === 'JUBELIO_ERROR' && /wallet/i.test(e.message));
    assert.equal(t.container.orderService.getOrder(order.id).shipment.state, 'FAILED');

    await t.admin('/wallet', { balance: 500000 });
    const ok = await t.container.shipmentService.createForOrder(order.id);
    assert.equal(ok.shipment.state, 'CREATED');
  } finally { await t.teardown(); }
});

test('token kedaluwarsa (401) -> otomatis generate token baru lalu request diulang', async () => {
  const t = await setup();
  try {
    await t.container.rateService.getQuotes({ destination: { zipcode: '12820' }, items: [{ sku: 'A', quantity: 1, price: 1000, weightGram: 100, lengthCm: 5, widthCm: 5, heightCm: 5 }] });
    const before = (await t.admin('/state')).activeTokens;
    await t.admin('/expire-tokens', {});
    const r = await t.container.rateService.getQuotes({ destination: { zipcode: '12820' }, items: [{ sku: 'A', quantity: 1, price: 1000, weightGram: 100, lengthCm: 5, widthCm: 5, heightCm: 5 }] });
    assert.ok(r.quotes.length > 0);
    assert.equal(before, 1);
    assert.equal((await t.admin('/state')).activeTokens, 1);
  } finally { await t.teardown(); }
});

test('pembatalan resi: sebelum pickup OK; setelah pickup ditolak; kurir tanpa pembatalan ditolak', async () => {
  const t = await setup();
  try {
    // 1) OK sebelum pickup, order kembali READY_TO_SHIP dan bisa dibuatkan resi baru
    const a = await readyOrder(t.container);
    await t.container.shipmentService.createForOrder(a.id);
    const canceled = await t.container.shipmentService.cancelForOrder(a.id, 'Barang belum siap');
    assert.equal(canceled.status, 'READY_TO_SHIP');
    assert.equal(canceled.shipment.state, 'CANCELED');
    await tick(250); // webhook CANCELED dari mock tiba -> status sama, tidak ada efek samping
    assert.equal(t.container.orderService.getOrder(a.id).status, 'READY_TO_SHIP');
    const reship = await t.container.shipmentService.createForOrder(a.id);
    assert.equal(reship.shipment.state, 'CREATED');

    // 2) setelah dijemput -> ditolak oleh guard lokal
    await t.admin('/simulate', { awb: reship.shipment.awb, status: 'PICKED_UP' });
    await tick();
    await assert.rejects(() => t.container.shipmentService.cancelForOrder(a.id), { code: 'CONFLICT' });

    // 3) SiCepat GOKIL: kurir tidak mengizinkan pembatalan -> pesan Jubelio dipetakan
    const b = await readyOrder(t.container, SICEPAT_GOKIL);
    await t.container.shipmentService.createForOrder(b.id);
    await assert.rejects(() => t.container.shipmentService.cancelForOrder(b.id), (e) => e.code === 'CONFLICT' && /tidak mengizinkan/.test(e.message));
  } finally { await t.teardown(); }
});

test('COD: hanya layanan yang mendukung COD; biaya COD masuk total; DELIVERED -> COD_COLLECTED', async () => {
  const t = await setup();
  try {
    await assert.rejects(() => readyOrder(t.container, JNE_REG, { cod: true }), { code: 'VALIDATION_ERROR' });
    const order = await readyOrder(t.container, JNT_EZ, { cod: true });
    assert.equal(order.status, 'READY_TO_SHIP');
    assert.ok(order.shipping.codFee > 0);
    assert.equal(order.total, order.subtotal + order.shipping.buyerPays);

    const { shipment } = await t.container.shipmentService.createForOrder(order.id);
    await t.admin('/simulate', { awb: shipment.awb, status: 'DELIVERED' });
    await tick();
    assert.equal(t.container.orderService.getOrder(order.id).payment.status, 'COD_COLLECTED');
  } finally { await t.teardown(); }
});

test('rekonsiliasi: webhook hilang -> status terkejar lewat GET /shipments/awb/{awb}', async () => {
  const t = await setup();
  try {
    const order = await readyOrder(t.container);
    const { shipment } = await t.container.shipmentService.createForOrder(order.id);
    t.mock.setWebhookUrl(''); // webhook "hilang"
    await t.admin('/simulate', { awb: shipment.awb, status: 'ON_DELIVERY' });
    assert.equal(t.container.orderService.getOrder(order.id).shipment.status, 'WAITING');

    const summary = await t.container.shipmentService.reconcileStale({ olderThanMinutes: -1 });
    assert.deepEqual(summary, { checked: 1, updated: 1, errors: 0 });
    assert.equal(t.container.orderService.getOrder(order.id).status, 'SHIPPED');
  } finally { await t.teardown(); }
});

test('harga & berat selalu dari katalog server; SKU asing & layanan tak tersedia ditolak', async () => {
  const t = await setup();
  try {
    await assert.rejects(() => t.container.orderService.createOrder({ customer, items: [{ sku: 'SKU-GAIB', qty: 1 }], courier: JNE_REG }), { code: 'VALIDATION_ERROR' });
    await assert.rejects(() => t.container.orderService.createOrder({ customer, items: [{ sku: 'SKU-KAOS-M', qty: 1 }], courier: { courierId: 99, courierServiceId: 9999 } }), /tidak tersedia/);
    await assert.rejects(() => t.container.orderService.createOrder({ customer: { name: 'x' }, items: [{ sku: 'SKU-KAOS-M', qty: 1 }], courier: JNE_REG }), /customer/);
  } finally { await t.teardown(); }
});
