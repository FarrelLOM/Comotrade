'use strict';
/**
 * "Composition root": satu-satunya tempat semua objek dirakit (dependency injection manual).
 * Keuntungan: test bisa merakit versi sendiri (mis. base URL ke mock server),
 * dan kamu langsung melihat siapa bergantung pada siapa.
 */
const { TokenManager } = require('./lib/tokenManager');
const { JubelioClient } = require('./lib/jubelioClient');
const { createStore } = require('./store/db');
const { createRegionService } = require('./services/regionService');
const { createRateService } = require('./services/rateService');
const { createOrderService } = require('./services/orderService');
const { createTrackingService } = require('./services/trackingService');
const { createShipmentService } = require('./services/shipmentService');
const { createWebhookService } = require('./services/webhookService');

function createContainer(config, { catalog = require('./data/products.json'), fetchImpl, sleep } = {}) {
  const j = config.jubelio;
  const tokenManager = new TokenManager({ baseUrl: j.baseUrl, clientId: j.clientId, clientSecret: j.clientSecret, timeoutMs: j.timeoutMs, fetchImpl });
  const client = new JubelioClient({ baseUrl: j.baseUrl, timeoutMs: j.timeoutMs, fetchImpl, sleep }, tokenManager);

  const store = createStore();
  const regionService = createRegionService({ client });
  const rateService = createRateService({ client, config });
  const orderService = createOrderService({ store, rateService, catalog });
  const trackingService = createTrackingService({ store });
  const shipmentService = createShipmentService({ client, store, config, trackingService });
  const webhookService = createWebhookService({ store, trackingService, config });

  return { config, tokenManager, client, store, catalog, regionService, rateService, orderService, trackingService, shipmentService, webhookService };
}

module.exports = { createContainer };
