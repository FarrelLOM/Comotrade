'use strict';
const express = require('express');
const asyncHandler = require('../lib/asyncHandler');

/** Alur order contoh: buat -> bayar -> buat resi -> (batalkan) -> tracking */
module.exports = ({ orderService, shipmentService }) => {
  const r = express.Router();

  r.get('/', (_req, res) => res.json(orderService.listOrders()));
  r.post('/', asyncHandler(async (req, res) => res.status(201).json(await orderService.createOrder(req.body || {}))));
  r.get('/:id', (req, res) => res.json(orderService.getOrder(req.params.id)));

  // Simulasi pembayaran lunas (di dunia nyata dipicu webhook payment gateway)
  r.post('/:id/pay', (req, res) => res.json(orderService.markPaid(req.params.id)));

  // Admin/gudang menekan "Proses pengiriman" -> POST /shipments/create
  r.post('/:id/ship', asyncHandler(async (req, res) => res.status(201).json(await shipmentService.createForOrder(req.params.id))));
  r.post('/:id/cancel-shipment', asyncHandler(async (req, res) =>
    res.json(await shipmentService.cancelForOrder(req.params.id, req.body && req.body.reason))));

  // State UNKNOWN (timeout saat create resi) diselesaikan manual: body { awb? }
  r.post('/:id/resolve-unknown', asyncHandler(async (req, res) =>
    res.json(await shipmentService.resolveUnknown(req.params.id, req.body || {}))));

  // Tracking: data tersimpan (hasil webhook) + data langsung dari Jubelio (GET /shipments/awb/{awb})
  r.get('/:id/tracking', asyncHandler(async (req, res) => {
    const order = orderService.getOrder(req.params.id);
    const live = req.query.live === '1' ? await shipmentService.getLiveDetail(req.params.id) : undefined;
    res.json({ orderStatus: order.status, shipment: order.shipment, live });
  }));

  return r;
};
