'use strict';
const express = require('express');
const asyncHandler = require('../lib/asyncHandler');
const { ValidationError } = require('../lib/errors');

module.exports = ({ rateService, orderService, shipmentService, catalog, config }) => {
  const r = express.Router();
  const bySku = new Map(catalog.map((p) => [p.sku, p]));

  /**
   * POST /api/shipping/rates   (halaman checkout)
   * body: { destination: { areaId, zipcode, coordinate? }, items: [{ sku, qty }], serviceCategoryId?, cod? }
   */
  r.post('/rates', asyncHandler(async (req, res) => {
    const { destination, items, serviceCategoryId, cod = false } = req.body || {};
    if (!destination || !destination.zipcode) throw new ValidationError('destination.zipcode wajib diisi');
    if (!Array.isArray(items) || !items.length) throw new ValidationError('items wajib diisi');

    const lines = items.map(({ sku, qty }) => {
      const p = bySku.get(sku);
      if (!p) throw new ValidationError(`SKU tidak dikenal: ${sku}`);
      return { ...p, quantity: Number(qty) };
    });
    const subtotal = lines.reduce((s, l) => s + l.price * l.quantity, 0);

    const { package: pkg, quotes } = await rateService.getQuotes({ destination, items: lines, serviceCategoryId, cod });
    res.json({
      subtotal,
      package: pkg,
      quotes: quotes.map((q) => ({ ...q, buyer: rateService.computeBuyerShipping(q, { subtotal, cod }) })),
      cheapest: quotes.length ? rateService.pickCheapest(quotes).serviceName : null,
    });
  }));

  /** POST /api/shipping/reconcile -> tarik status terbaru untuk resi yang lama tidak berubah. */
  r.post('/reconcile', asyncHandler(async (req, res) => {
    const minutes = Number(req.body && req.body.olderThanMinutes);
    res.json(await shipmentService.reconcileStale({ olderThanMinutes: Number.isFinite(minutes) ? minutes : config.reconcile.staleAfterMinutes }));
  }));

  return r;
};
