'use strict';
const express = require('express');
const logger = require('../lib/logger');

/**
 * POST /webhooks/jubelio  <- didaftarkan di dashboard Jubelio (Setting > Developer > Webhook).
 * Urutan wajib: verifikasi signature -> balas 200 cepat -> proses di belakang.
 */
module.exports = ({ webhookService }) => {
  const r = express.Router();

  r.post('/jubelio', (req, res) => {
    const signature = req.get('x-jubelio-signature');
    if (!webhookService.verify(req.rawBody, signature)) {
      logger.warn('Webhook ditolak: signature tidak valid');
      return res.status(401).json({ ok: false, error: 'invalid signature' });
    }
    res.status(200).json({ ok: true });

    setImmediate(() => {
      try {
        const result = webhookService.handle(req.body);
        logger.info('Webhook diproses', { awb: req.body && req.body.awb, ...result });
      } catch (err) {
        // Jangan lempar: respons sudah terkirim. Catat; rekonsiliasi akan menutup celahnya.
        logger.error('Webhook gagal diproses', { message: err.message, awb: req.body && req.body.awb });
      }
    });
  });

  return r;
};
