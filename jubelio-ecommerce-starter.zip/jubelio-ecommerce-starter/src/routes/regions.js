'use strict';
const express = require('express');
const asyncHandler = require('../lib/asyncHandler');

/** /api/regions -> bantu form alamat: autocomplete atau dropdown berjenjang. */
module.exports = ({ regionService }) => {
  const r = express.Router();
  r.get('/search', asyncHandler(async (req, res) => res.json(await regionService.search(req.query.q))));
  r.get('/provinces', asyncHandler(async (_req, res) => res.json(await regionService.provinces())));
  r.get('/provinces/:id/cities', asyncHandler(async (req, res) => res.json(await regionService.cities(req.params.id))));
  r.get('/cities/:id/districts', asyncHandler(async (req, res) => res.json(await regionService.districts(req.params.id))));
  r.get('/districts/:id/areas', asyncHandler(async (req, res) => res.json(await regionService.areas(req.params.id))));
  return r;
};
