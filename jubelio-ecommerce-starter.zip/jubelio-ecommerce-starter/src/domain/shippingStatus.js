'use strict';
/**
 * Status pengiriman Jubelio (field `latest_status`) + aturan transisi.
 * Kode status MENTAH kurir (F02, S01, D09, ...) berbeda-beda tiap kurir:
 * jangan dipakai untuk logika bisnis, simpan saja untuk ditampilkan.
 */

const SHIPMENT_STATUS = Object.freeze({
  WAITING: 'WAITING',
  CONFIRMED_BY_COURIER: 'CONFIRMED_BY_COURIER',
  ON_THE_WAY_PICK_UP: 'ON_THE_WAY_PICK_UP',
  PICKED_UP: 'PICKED_UP',
  ON_DELIVERY: 'ON_DELIVERY',
  ON_HOLD: 'ON_HOLD',
  DELIVERED: 'DELIVERED',
  RETURNED: 'RETURNED',
  CANCELED: 'CANCELED',
  SHIPMENT_ISSUE: 'SHIPMENT_ISSUE',
});

/** Status akhir: setelah ini tidak boleh berubah lagi. */
const TERMINAL = new Set(['DELIVERED', 'RETURNED', 'CANCELED']);

/** Resi hanya boleh dibatalkan sebelum kurir mengambil barang (API Contract 3.2). */
const CANCELABLE = new Set(['WAITING', 'CONFIRMED_BY_COURIER', 'ON_THE_WAY_PICK_UP']);

/** Status order milik platform kita. */
const ORDER_STATUS = Object.freeze({
  PENDING_PAYMENT: 'PENDING_PAYMENT',
  READY_TO_SHIP: 'READY_TO_SHIP',     // sudah dibayar / COD, resi belum ada (atau resi dibatalkan)
  AWAITING_PICKUP: 'AWAITING_PICKUP', // resi terbit, menunggu kurir menjemput
  SHIPPED: 'SHIPPED',
  SHIPMENT_ISSUE: 'SHIPMENT_ISSUE',
  DELIVERED: 'DELIVERED',
  RETURNED: 'RETURNED',
});

const isKnownStatus = (s) => Object.prototype.hasOwnProperty.call(SHIPMENT_STATUS, s);
const isTerminal = (s) => TERMINAL.has(s);
const isCancelable = (s) => CANCELABLE.has(s);

/**
 * Putuskan apakah update status dari webhook / polling boleh diterapkan.
 * Webhook bisa datang DOBEL dan TERBALIK urutannya, jadi:
 *   1) status tidak dikenal  -> abaikan
 *   2) status sama           -> tidak ada perubahan status (event tetap dicatat)
 *   3) status saat ini final -> abaikan (DELIVERED tidak boleh "mundur")
 *   4) event lebih LAMA dari event yang sudah diterapkan -> abaikan (stale)
 */
function shouldApplyUpdate({ currentStatus, currentEventAt, incomingStatus, incomingEventAt }) {
  if (!isKnownStatus(incomingStatus)) return { apply: false, reason: 'UNKNOWN_STATUS' };
  if (currentStatus === incomingStatus) return { apply: false, reason: 'SAME_STATUS' };
  if (isTerminal(currentStatus)) return { apply: false, reason: 'ALREADY_TERMINAL' };
  if (currentEventAt && incomingEventAt && Date.parse(incomingEventAt) < Date.parse(currentEventAt)) {
    return { apply: false, reason: 'STALE_EVENT' };
  }
  return { apply: true };
}

/** Petakan status pengiriman -> status order. */
function toOrderStatus(shipmentStatus) {
  switch (shipmentStatus) {
    case 'WAITING':
    case 'CONFIRMED_BY_COURIER':
    case 'ON_THE_WAY_PICK_UP':
      return ORDER_STATUS.AWAITING_PICKUP;
    case 'PICKED_UP':
    case 'ON_DELIVERY':
      return ORDER_STATUS.SHIPPED;
    case 'ON_HOLD':
    case 'SHIPMENT_ISSUE':
      return ORDER_STATUS.SHIPMENT_ISSUE;
    case 'DELIVERED':
      return ORDER_STATUS.DELIVERED;
    case 'RETURNED':
      return ORDER_STATUS.RETURNED;
    case 'CANCELED':
      return ORDER_STATUS.READY_TO_SHIP; // resi batal -> order kembali siap dikirim (buat resi baru)
    default:
      return null;
  }
}

module.exports = {
  SHIPMENT_STATUS,
  ORDER_STATUS,
  isKnownStatus,
  isTerminal,
  isCancelable,
  shouldApplyUpdate,
  toOrderStatus,
};
