'use strict';
const logger = require('./lib/logger');
const { AppError } = require('./lib/errors');

const notFound = (req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: `${req.method} ${req.originalUrl} tidak ada` } });

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, _req, res, _next) => {
  if (err instanceof AppError) {
    return res.status(err.status).json({ error: { code: err.code, message: err.message, details: err.details } });
  }
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { code: 'INVALID_JSON', message: 'Body bukan JSON yang valid' } });
  }
  logger.error('Unhandled error', { message: err && err.message, stack: err && err.stack });
  return res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Terjadi kesalahan pada server' } });
};

module.exports = { notFound, errorHandler };
