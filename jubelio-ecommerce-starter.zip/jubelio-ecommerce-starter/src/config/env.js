'use strict';
/**
 * Konfigurasi aplikasi. File ini TIDAK memanggil dotenv; pemanggilan dotenv
 * dilakukan di server.js (entrypoint) supaya modul ini mudah dites:
 * cukup kirim objek `env` buatan sendiri ke loadConfig().
 */

const num = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));

function loadConfig(env = process.env) {
  return {
    env: env.NODE_ENV || 'development',
    port: num(env.PORT, 3000),

    jubelio: {
      // Production: https://api-shipment.jubelio.com | Staging: https://api-shipment.sandbox.jubelio.com
      baseUrl: (env.JUBELIO_BASE_URL || 'https://api-shipment.sandbox.jubelio.com').replace(/\/+$/, ''),
      clientId: env.JUBELIO_CLIENT_ID || '',
      clientSecret: env.JUBELIO_CLIENT_SECRET || '',
      webhookSecret: env.JUBELIO_WEBHOOK_SECRET || '',
      timeoutMs: num(env.JUBELIO_TIMEOUT_MS, 15000),
      refNoMode: env.JUBELIO_REF_NO_MODE === 'order' ? 'order' : 'auto',
    },

    // Alamat gudang pengirim (origin). Di produksi: ambil per gudang dari database.
    warehouse: {
      name: env.WAREHOUSE_NAME || 'Toko Contoh',
      phone: env.WAREHOUSE_PHONE || '081200000000',
      email: env.WAREHOUSE_EMAIL || '',
      address: env.WAREHOUSE_ADDRESS || 'Jl. Pengirim No. 1',
      areaId: env.WAREHOUSE_AREA_ID || '3174021004',
      zipcode: env.WAREHOUSE_ZIPCODE || '12920',
      coordinate: env.WAREHOUSE_COORDINATE || '',
    },

    shipping: {
      volumetricDivisor: num(env.VOLUMETRIC_DIVISOR, 6000),
      subsidy: {
        minSubtotal: num(env.FREE_SHIPPING_MIN_SUBTOTAL, 200000),
        maxSubsidy: num(env.FREE_SHIPPING_MAX_SUBSIDY, 20000),
      },
      // Selisih harga resi vs snapshot checkout yang masih dianggap wajar (rupiah)
      priceDriftTolerance: num(env.PRICE_DRIFT_TOLERANCE, 0),
    },

    reconcile: {
      intervalMinutes: num(env.RECONCILE_INTERVAL_MINUTES, 0),
      staleAfterMinutes: num(env.RECONCILE_STALE_AFTER_MINUTES, 60),
    },
  };
}

module.exports = { loadConfig };
