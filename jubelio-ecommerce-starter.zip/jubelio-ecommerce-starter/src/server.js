'use strict';
require('dotenv').config();
const { loadConfig } = require('./config/env');
const { createContainer } = require('./container');
const { createApp } = require('./app');
const logger = require('./lib/logger');

const config = loadConfig();
const container = createContainer(config);
const app = createApp(container);

const server = app.listen(config.port, () => {
  logger.info('Server berjalan', { port: config.port, jubelio: config.jubelio.baseUrl, env: config.env });
});

// Rekonsiliasi berkala (opsional). Di produksi gunakan job scheduler/queue.
if (config.reconcile.intervalMinutes > 0) {
  const timer = setInterval(() => {
    container.shipmentService
      .reconcileStale({ olderThanMinutes: config.reconcile.staleAfterMinutes })
      .then((s) => logger.info('Rekonsiliasi selesai', s))
      .catch((e) => logger.error('Rekonsiliasi gagal', { message: e.message }));
  }, config.reconcile.intervalMinutes * 60_000);
  timer.unref();
}

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(() => process.exit(0)));
}
