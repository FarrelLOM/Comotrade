'use strict';
const logger = require('../lib/logger');
const { shouldApplyUpdate, toOrderStatus, ORDER_STATUS } = require('../domain/shippingStatus');

/**
 * Satu-satunya pintu untuk mengubah status pengiriman. Dipakai oleh:
 *   - webhook  (payload.tracking = SATU objek)
 *   - polling / rekonsiliasi  (detail AWB: tracking = ARRAY riwayat)
 * Karena jalurnya sama, perilaku keduanya konsisten.
 */
function createTrackingService({ store }) {
  const toArray = (t) => (Array.isArray(t) ? t : t ? [t] : []);

  function applyStatusUpdate({ awb, latestStatus, tracking, extras = {}, source = 'webhook' }) {
    const orderId = store.findOrderIdByAwb(awb);
    if (!orderId) return { applied: false, reason: 'UNKNOWN_AWB' };
    const order = store.orders.get(orderId);
    const sh = order.shipment;
    if (!sh) return { applied: false, reason: 'NO_SHIPMENT' };

    // 1) Catat event riwayat (dedup berdasarkan status+tanggal)
    const entries = toArray(tracking);
    for (const e of entries) {
      const dup = sh.events.some((x) => x.status === e.status && x.date === e.date);
      if (!dup) sh.events.push({ date: e.date, status: e.status, detail: e.status_detail, source });
    }
    sh.events.sort((a, b) => Date.parse(a.date) - Date.parse(b.date));

    // 2) Simpan bukti/link yang dikirim Jubelio bila ada (foto POD, tanda tangan, live tracking)
    for (const [k, v] of Object.entries(extras)) if (v) sh[k] = v;

    // 3) Tentukan apakah status boleh berubah
    const incomingEventAt = entries.length ? entries[entries.length - 1].date : new Date().toISOString();
    const decision = shouldApplyUpdate({
      currentStatus: sh.status,
      currentEventAt: sh.lastEventAt,
      incomingStatus: latestStatus,
      incomingEventAt,
    });
    if (!decision.apply) {
      store.orders.save(order);
      return { applied: false, reason: decision.reason, orderId };
    }

    sh.status = latestStatus;
    sh.lastEventAt = incomingEventAt;
    if (latestStatus === 'CANCELED') sh.state = 'CANCELED';
    order.status = toOrderStatus(latestStatus) || order.status;
    if (latestStatus === 'DELIVERED' && order.payment.method === 'COD') order.payment.status = 'COD_COLLECTED';
    store.orders.save(order);

    logger.info('Status pengiriman diperbarui', { orderId, awb, latestStatus, source });
    return { applied: true, orderId, orderStatus: order.status };
  }

  return { applyStatusUpdate, ORDER_STATUS };
}

module.exports = { createTrackingService };
