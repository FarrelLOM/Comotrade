'use strict';
const { ValidationError } = require('../lib/errors');

/**
 * Kalkulasi berat & dimensi paket.
 * Satuan mengikuti API Contract: berat = GRAM, dimensi = CM.
 *
 * Berat volumetrik = (panjang x lebar x tinggi) / pembagi  -> kilogram.
 * Pembagi 6000 lazim untuk kurir darat, tetapi Jubelio tidak mendokumentasikannya;
 * Jubelio/kurir yang menghitung tarif sebenarnya. Fungsi ini hanya ESTIMASI lokal
 * (misal memilih ukuran kardus atau memperingatkan paket besar-ringan).
 */
function volumetricWeightGram({ length, width, height }, divisor = 6000) {
  return Math.ceil(((length * width * height) / divisor) * 1000);
}

/** Berat yang ditagih = yang terbesar antara berat aktual dan volumetrik. */
function chargeableWeightGram({ weight, length, width, height }, divisor = 6000) {
  return Math.max(weight, volumetricWeightGram({ length, width, height }, divisor));
}

const isPos = (n) => typeof n === 'number' && Number.isFinite(n) && n > 0;

/**
 * Gabungkan item keranjang menjadi satu paket.
 * Input item: { sku, name, price, quantity, weightGram, lengthCm, widthCm, heightCm }
 *
 * Heuristik dimensi (SEDERHANA, untuk belajar): tumpuk semua barang ke atas ->
 *   panjang = max(panjang), lebar = max(lebar), tinggi = SUM(tinggi x qty).
 * Di produksi gunakan aturan kemasan nyata (pilihan kardus, bin-packing, dsb).
 */
function buildPackage(items, { divisor = 6000 } = {}) {
  if (!Array.isArray(items) || items.length === 0) throw new ValidationError('Item tidak boleh kosong');

  let totalWeightGram = 0;
  let totalValue = 0;
  let length = 0;
  let width = 0;
  let height = 0;

  for (const it of items) {
    for (const f of ['quantity', 'weightGram', 'lengthCm', 'widthCm', 'heightCm']) {
      if (!isPos(it[f])) throw new ValidationError(`Item ${it.sku || it.name}: field ${f} harus angka > 0`);
    }
    totalWeightGram += it.weightGram * it.quantity;
    totalValue += (it.price || 0) * it.quantity;
    length = Math.max(length, it.lengthCm);
    width = Math.max(width, it.widthCm);
    height += it.heightCm * it.quantity;
  }

  const packageDetail = { length, width, height, weight: totalWeightGram };
  return {
    totalWeightGram,
    totalValue,
    packageDetail,
    volumetricWeightGram: volumetricWeightGram(packageDetail, divisor),
    chargeableWeightGram: chargeableWeightGram(packageDetail, divisor),
  };
}

module.exports = { volumetricWeightGram, chargeableWeightGram, buildPackage };
