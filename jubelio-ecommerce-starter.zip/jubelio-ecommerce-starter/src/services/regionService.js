'use strict';
const { ValidationError } = require('../lib/errors');

/**
 * Pencarian wilayah. Jubelio memakai `area_id` (kode kelurahan/desa, 10 digit) +
 * `zipcode`. Simpan KEDUANYA di alamat pelanggan dan alamat gudang.
 * Hierarki wilayah jarang berubah -> di-cache (TTL 24 jam). Pencarian teks: 10 menit.
 */
function createRegionService({ client, ttlMs = 24 * 3600 * 1000, searchTtlMs = 10 * 60 * 1000, now = () => Date.now() }) {
  const cache = new Map(); // key -> { value, expiresAt }

  async function cached(key, ttl, loader) {
    const hit = cache.get(key);
    if (hit && hit.expiresAt > now()) return hit.value;
    const value = await loader();
    cache.set(key, { value, expiresAt: now() + ttl });
    return value;
  }

  return {
    /** Autocomplete alamat: "tebet" -> daftar kelurahan lengkap dengan area_id & kode pos. */
    search(q) {
      const term = String(q || '').trim();
      if (term.length < 3) throw new ValidationError('Kata kunci minimal 3 karakter');
      return cached(`search:${term.toLowerCase()}`, searchTtlMs, () => client.searchRegions(term));
    },
    provinces: () => cached('provinces', ttlMs, () => client.getProvinces()),
    cities: (provinceId) => cached(`cities:${provinceId}`, ttlMs, () => client.getCities(provinceId)),
    districts: (cityId) => cached(`districts:${cityId}`, ttlMs, () => client.getDistricts(cityId)),
    areas: (districtId) => cached(`areas:${districtId}`, ttlMs, () => client.getAreas(districtId)),
  };
}

module.exports = { createRegionService };
