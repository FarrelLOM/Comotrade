'use strict';
const { ValidationError, NotFoundError, ConflictError } = require('../lib/errors');
const { ORDER_STATUS } = require('../domain/shippingStatus');

/**
 * Order sederhana untuk mendemokan alur pengiriman.
 * PRINSIP: harga, berat, dan dimensi produk diambil dari KATALOG SERVER, bukan dari body request.
 */
function createOrderService({ store, rateService, catalog }) {
  const bySku = new Map(catalog.map((p) => [p.sku, p]));

  function validateCustomer(c) {
    if (!c) throw new ValidationError('customer wajib diisi');
    const missing = ['name', 'phone', 'address', 'zipcode'].filter((f) => !c[f]);
    if (missing.length) throw new ValidationError(`Field customer wajib: ${missing.join(', ')}`);
  }

  function resolveItems(rawItems) {
    if (!Array.isArray(rawItems) || rawItems.length === 0) throw new ValidationError('items wajib diisi');
    return rawItems.map(({ sku, qty }) => {
      const p = bySku.get(sku);
      if (!p) throw new ValidationError(`SKU tidak dikenal: ${sku}`);
      const quantity = Number(qty);
      if (!Number.isInteger(quantity) || quantity < 1) throw new ValidationError(`qty tidak valid untuk ${sku}`);
      return { ...p, quantity };
    });
  }

  async function createOrder({ customer, items, courier, withInsurance = false, cod = false }) {
    validateCustomer(customer);
    if (!courier || !courier.courierId || !courier.courierServiceId) {
      throw new ValidationError('courier.courierId dan courier.courierServiceId wajib (ambil dari hasil /api/shipping/rates)');
    }
    const lines = resolveItems(items);
    const subtotal = lines.reduce((s, l) => s + l.price * l.quantity, 0);

    const destination = { areaId: customer.areaId, zipcode: customer.zipcode, coordinate: customer.coordinate };
    const { package: pkg, quote } = await rateService.resolveQuote({
      destination,
      items: lines,
      courierId: courier.courierId,
      courierServiceId: courier.courierServiceId,
      cod,
    });
    const fee = rateService.computeBuyerShipping(quote, { subtotal, withInsurance, cod });

    const order = {
      id: store.orders.nextId(),
      status: cod ? ORDER_STATUS.READY_TO_SHIP : ORDER_STATUS.PENDING_PAYMENT,
      customer,
      items: lines,
      subtotal,
      // SNAPSHOT pilihan kurir saat checkout (tarif bisa berubah, jadi simpan apa yang dijanjikan ke pembeli)
      shipping: { ...quote, ...fee, withInsurance, isCod: cod, package: pkg },
      total: subtotal + fee.buyerPays,
      payment: { method: cod ? 'COD' : 'TRANSFER', status: cod ? 'COD_PENDING' : 'UNPAID' },
      shipment: null,
      createdAt: new Date().toISOString(),
    };
    return store.orders.save(order);
  }

  function getOrder(id) {
    const order = store.orders.get(id);
    if (!order) throw new NotFoundError(`Order ${id} tidak ditemukan`);
    return order;
  }

  /** Simulasi pembayaran sukses (di dunia nyata dipanggil oleh webhook payment gateway). */
  function markPaid(id) {
    const order = getOrder(id);
    if (order.status !== ORDER_STATUS.PENDING_PAYMENT) {
      throw new ConflictError(`Order berstatus ${order.status}, tidak bisa ditandai lunas`);
    }
    order.payment.status = 'PAID';
    order.status = ORDER_STATUS.READY_TO_SHIP;
    return store.orders.save(order);
  }

  return { createOrder, getOrder, markPaid, listOrders: () => store.orders.list() };
}

module.exports = { createOrderService };
