'use strict';
const { ValidationError } = require('../lib/errors');
const { buildPackage } = require('./shippingCalc');

const DAY_MS = 86_400_000;

const compact = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== ''));

/**
 * Ongkos kirim. Alur di checkout:
 *   1. buildPackage(items)            -> berat total + dimensi paket
 *   2. POST /rates/all (atau /rates)  -> daftar layanan semua kurir
 *   3. normalisasi + urutkan          -> tampilkan ke pelanggan
 *   4. saat pelanggan memilih         -> resolveQuote() ambil ULANG dari server (jangan percaya harga dari browser)
 *   5. computeBuyerShipping()         -> subsidi ongkir milik platformmu
 */
function createRateService({ client, config, now = () => Date.now() }) {
  function toLocation(loc) {
    return compact({ area_id: loc.areaId, zipcode: loc.zipcode, coordinate: loc.coordinate });
  }

  function buildRatesPayload({ origin, destination, pkg, serviceCategoryId }) {
    if (!destination || !destination.zipcode) throw new ValidationError('destination.zipcode wajib diisi');
    // Kontrak: "untuk volumetrik isi salah satu: items ATAU package_detail" -> kita kirim package_detail.
    const payload = {
      origin: toLocation(origin),
      destination: toLocation(destination),
      package_detail: { ...pkg.packageDetail },
      weight: pkg.totalWeightGram, // wajib, gram
      total_value: pkg.totalValue, // dipakai menghitung asuransi
    };
    if (serviceCategoryId) payload.service_category_id = serviceCategoryId; // 1..6 (hanya /rates)
    return payload;
  }

  function normalize(r) {
    const etaFrom = r.eta_from ? Date.parse(r.eta_from) : null;
    const etaTo = r.eta_to ? Date.parse(r.eta_to) : null;
    const daysFrom = (t) => (t ? Math.max(1, Math.ceil((t - now()) / DAY_MS)) : null);
    return {
      courierId: r.courier_id,
      courierName: r.courier_name,
      serviceId: r.courier_service_id,
      serviceCode: r.courier_service_code,
      serviceName: r.courier_service_name,
      category: r.courier_service_category,
      // PAKAI `rates`, BUKAN `final_rates` (API Contract 6.1). Diskon = urusan platform kita.
      price: r.rates,
      insurance: r.shipping_insurance || 0,
      codSupported: Boolean(r.is_cod_supported),
      codFee: r.cod_fee || 0,
      etaFrom: r.eta_from || null,
      etaTo: r.eta_to || null,
      etaDays: etaFrom && etaTo ? { min: daysFrom(etaFrom), max: daysFrom(etaTo) } : null,
      logo: r.courier_logo || null,
    };
  }

  async function getQuotes({ origin = config.warehouse, destination, items, serviceCategoryId, cod = false }) {
    const pkg = buildPackage(items, { divisor: config.shipping.volumetricDivisor });
    const payload = buildRatesPayload({ origin, destination, pkg, serviceCategoryId });
    const raw = serviceCategoryId ? await client.getRates(payload) : await client.getAllRates(payload);
    let quotes = (Array.isArray(raw) ? raw : []).map(normalize);
    if (cod) quotes = quotes.filter((q) => q.codSupported);
    quotes.sort((a, b) => a.price - b.price);
    return { package: pkg, quotes };
  }

  /** Ambil ulang tarif lalu cari layanan yang dipilih. Harga SELALU dari server. */
  async function resolveQuote({ origin, destination, items, courierId, courierServiceId, cod = false }) {
    const { package: pkg, quotes } = await getQuotes({ origin, destination, items, cod });
    const quote = quotes.find((q) => String(q.courierId) === String(courierId) && String(q.serviceId) === String(courierServiceId));
    if (!quote) throw new ValidationError('Layanan kurir tidak tersedia untuk rute/paket ini (atau tidak mendukung COD)');
    return { package: pkg, quote };
  }

  /**
   * Hitung ongkir yang dibayar pembeli. Promo Gratis/Diskon Ongkir di dashboard Jubelio
   * hanya berlaku untuk channel Jubelio Store -> untuk platform custom, subsidi dihitung di sini.
   * Aturan contoh: subtotal >= minSubtotal -> subsidi sebesar ongkir, maksimal maxSubsidy.
   */
  function computeBuyerShipping(quote, { subtotal, withInsurance = false, cod = false }) {
    const { minSubtotal, maxSubsidy } = config.shipping.subsidy;
    const subsidy = subtotal >= minSubtotal ? Math.min(maxSubsidy, quote.price) : 0;
    const insurance = withInsurance ? quote.insurance : 0;
    const codFee = cod ? quote.codFee : 0;
    return {
      carrierPrice: quote.price, // yang akan ditagihkan Jubelio ke kita
      subsidy, // ditanggung platform
      insurance,
      codFee,
      buyerPays: quote.price - subsidy + insurance + codFee,
    };
  }

  const pickCheapest = (quotes) => quotes.reduce((a, b) => (b.price < a.price ? b : a), quotes[0]);
  const pickFastest = (quotes) =>
    quotes.filter((q) => q.etaDays).reduce((a, b) => (b.etaDays.min < a.etaDays.min ? b : a), quotes.find((q) => q.etaDays));

  return { buildRatesPayload, normalize, getQuotes, resolveQuote, computeBuyerShipping, pickCheapest, pickFastest };
}

module.exports = { createRateService };
