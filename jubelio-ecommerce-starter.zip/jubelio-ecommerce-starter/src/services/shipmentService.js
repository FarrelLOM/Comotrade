'use strict';
const logger = require('../lib/logger');
const { NotFoundError, ConflictError, ValidationError, JubelioError } = require('../lib/errors');
const { ORDER_STATUS, isCancelable, isTerminal } = require('../domain/shippingStatus');

/** state resi di sisi KITA (berbeda dengan latest_status milik Jubelio): */
const ACTIVE_STATES = new Set(['CREATING', 'CREATED', 'UNKNOWN']);

const compact = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== ''));

/**
 * Pembuatan / pembatalan resi (AWB).
 *
 * Mesin state `order.shipment.state`:
 *
 *   (belum ada) --createForOrder--> CREATING --sukses--------> CREATED --cancel--> CANCELED
 *                                       |-----gagal jelas-----> FAILED   (boleh coba lagi)
 *                                       '-----timeout/putus---> UNKNOWN  (JANGAN coba lagi buta;
 *                                                                          cek dashboard Jubelio, lalu resolveUnknown)
 */
function createShipmentService({ client, store, config, trackingService, now = () => Date.now() }) {
  // Lock in-memory = hanya aman untuk SATU proses. Di produksi (multi-instance) pakai
  // unique constraint / SELECT ... FOR UPDATE / advisory lock di database.
  const locks = new Set();

  const party = (p) =>
    compact({ name: p.name, email: p.email, phone: p.phone, address: p.address, area_id: p.areaId, coordinate: p.coordinate, zipcode: p.zipcode });

  /** Bangun body POST /shipments/create (API Contract 3.1) dari order + snapshot kurir. */
  function buildCreatePayload(order) {
    const s = order.shipping;
    return {
      ref_no: config.jubelio.refNoMode === 'order' ? order.id : '[auto]',
      courier_id: s.courierId,
      courier_service_id: s.serviceId,
      shipping_insurance: s.withInsurance ? s.insurance : 0, // semantik angka ini belum jelas -> docs/PERTANYAAN_UNTUK_JUBELIO.md
      is_cod: Boolean(s.isCod),
      origin: party(config.warehouse),
      destination: party(order.customer),
      package_detail: { ...s.package.packageDetail },
      items: order.items.map((it) => ({
        item_code: it.sku,
        item_name: it.name,
        category: '-',
        quantity: it.quantity,
        value: it.price, // per unit atau total? belum jelas di kontrak -> kita kirim per unit
        weight: it.weightGram, // gram, per unit
        length: it.lengthCm,
        width: it.widthCm,
        height: it.heightCm,
      })),
    };
  }

  function getOrder(id) {
    const order = store.orders.get(id);
    if (!order) throw new NotFoundError(`Order ${id} tidak ditemukan`);
    return order;
  }

  async function createForOrder(orderId) {
    const order = getOrder(orderId);
    if (order.status !== ORDER_STATUS.READY_TO_SHIP) {
      throw new ConflictError(`Order berstatus ${order.status}; resi hanya bisa dibuat saat READY_TO_SHIP (sudah dibayar/COD)`);
    }
    const prev = order.shipment;
    if (locks.has(orderId) || (prev && ACTIVE_STATES.has(prev.state))) {
      throw new ConflictError(`Resi untuk order ini sudah ada / sedang diproses (state: ${prev ? prev.state : 'CREATING'})`, {
        hint: prev && prev.state === 'UNKNOWN' ? 'Cek dashboard Jubelio, lalu panggil /resolve-unknown' : undefined,
      });
    }

    locks.add(orderId);
    try {
      const attempts = (prev ? prev.attempts : 0) + 1;
      order.shipment = { state: 'CREATING', attempts, startedAt: new Date(now()).toISOString(), events: [] };
      store.orders.save(order); // simpan SEBELUM memanggil Jubelio: jejak bahwa kita sedang mencoba

      let res;
      try {
        res = await client.createShipment(buildCreatePayload(order));
      } catch (err) {
        const unknown = err instanceof JubelioError && err.outcomeUnknown;
        order.shipment = {
          ...order.shipment,
          state: unknown ? 'UNKNOWN' : 'FAILED',
          error: { code: err.code, message: err.message, body: err.body },
        };
        store.orders.save(order);
        logger.error(unknown ? 'Hasil create resi TIDAK DIKETAHUI' : 'Create resi gagal', { orderId, code: err.code, message: err.message });
        throw err;
      }

      const drift = res.price - order.shipping.carrierPrice;
      order.shipment = {
        ...order.shipment,
        state: 'CREATED',
        awb: res.awb,
        jubelioShipmentId: res.shipment_id,
        trackingUrl: res.tracking_url,
        price: res.price, // harga RIIL yang akan ditagihkan Jubelio (cocokkan dengan tagihan bulanan)
        priceDrift: drift,
        status: 'WAITING',
        lastEventAt: null,
        createdAt: new Date(now()).toISOString(),
      };
      delete order.shipment.error;
      store.indexAwb(res.awb, order.id);
      order.status = ORDER_STATUS.AWAITING_PICKUP;
      store.orders.save(order);

      if (Math.abs(drift) > config.shipping.priceDriftTolerance) {
        logger.warn('Harga resi berbeda dari snapshot checkout', { orderId, awb: res.awb, quoted: order.shipping.carrierPrice, actual: res.price });
      }
      logger.info('Resi dibuat', { orderId, awb: res.awb });
      return order;
    } finally {
      locks.delete(orderId);
    }
  }

  const CANCEL_MESSAGES = {
    'the courier do not accept cancellation': 'Kurir tidak mengizinkan pembatalan resi ini',
    'too close with pickup schedule': 'Pembatalan ditolak: waktu pickup terlalu dekat',
  };

  async function cancelForOrder(orderId, reason = 'Dibatalkan oleh penjual') {
    const order = getOrder(orderId);
    const sh = order.shipment;
    if (!sh || sh.state !== 'CREATED') throw new ConflictError('Tidak ada resi aktif untuk dibatalkan');
    // Guard lokal murah; keputusan akhir tetap di Jubelio/kurir (boleh menolak).
    if (!isCancelable(sh.status)) throw new ConflictError(`Resi berstatus ${sh.status}; hanya bisa dibatalkan sebelum barang dijemput`);

    try {
      await client.cancelShipment({ awbCode: sh.awb, reason });
    } catch (err) {
      const msg = err instanceof JubelioError && err.body && err.body.message;
      if (msg && CANCEL_MESSAGES[msg]) throw new ConflictError(CANCEL_MESSAGES[msg], { jubelioMessage: msg });
      throw err;
    }
    sh.state = 'CANCELED';
    sh.status = 'CANCELED';
    sh.cancelReason = reason;
    order.status = ORDER_STATUS.READY_TO_SHIP; // siap dibuatkan resi baru
    return store.orders.save(order);
  }

  async function getLiveDetail(orderId) {
    const sh = getOrder(orderId).shipment;
    if (!sh || !sh.awb) throw new ConflictError('Order ini belum punya resi');
    return client.getShipmentByAwb(sh.awb);
  }

  /**
   * Menyelesaikan state UNKNOWN setelah operator mengecek dashboard Jubelio.
   *  - awb diisi  -> resi ternyata TERBIT: verifikasi lewat API lalu tandai CREATED
   *  - awb kosong -> tidak ada resi: tandai FAILED supaya boleh dicoba lagi
   */
  async function resolveUnknown(orderId, { awb } = {}) {
    const order = getOrder(orderId);
    const sh = order.shipment;
    if (!sh || sh.state !== 'UNKNOWN') throw new ConflictError('Shipment tidak dalam state UNKNOWN');

    if (!awb) {
      order.shipment = { ...sh, state: 'FAILED', note: 'Operator memastikan tidak ada resi di Jubelio' };
      return store.orders.save(order);
    }
    const detail = await client.getShipmentByAwb(awb);
    if (!detail || detail.awb !== awb) throw new ValidationError('AWB tidak cocok dengan data Jubelio');
    order.shipment = {
      ...sh,
      state: 'CREATED',
      awb,
      jubelioShipmentId: detail.shipment_id,
      trackingUrl: detail.tracking_url,
      price: detail.price,
      status: 'WAITING',
      lastEventAt: null,
      events: [],
    };
    store.indexAwb(awb, order.id);
    order.status = ORDER_STATUS.AWAITING_PICKUP;
    store.orders.save(order);
    trackingService.applyStatusUpdate({ awb, latestStatus: detail.latest_status, tracking: detail.tracking, source: 'manual' });
    return store.orders.get(orderId);
  }

  /**
   * Rekonsiliasi: webhook bisa hilang / datang sebelum AWB terindeks. Untuk resi aktif yang
   * lama tidak berubah, tanyakan langsung ke Jubelio (GET /shipments/awb/{awb}).
   */
  async function reconcileStale({ olderThanMinutes = 60 } = {}) {
    const threshold = now() - olderThanMinutes * 60_000;
    const summary = { checked: 0, updated: 0, errors: 0 };
    for (const order of store.orders.list()) {
      const sh = order.shipment;
      if (!sh || sh.state !== 'CREATED' || isTerminal(sh.status)) continue;
      const lastSeen = Date.parse(sh.lastEventAt || sh.createdAt || 0);
      if (lastSeen > threshold) continue;
      summary.checked += 1;
      try {
        const d = await client.getShipmentByAwb(sh.awb);
        const r = trackingService.applyStatusUpdate({
          awb: sh.awb,
          latestStatus: d.latest_status,
          tracking: d.tracking,
          extras: { deliveredImgUrl: d.delivered_img_url, liveTrackingUrl: d.live_tracking_url },
          source: 'reconcile',
        });
        if (r.applied) summary.updated += 1;
      } catch (err) {
        summary.errors += 1;
        logger.error('Rekonsiliasi gagal', { orderId: order.id, awb: sh.awb, message: err.message });
      }
    }
    return summary;
  }

  return { buildCreatePayload, createForOrder, cancelForOrder, getLiveDetail, resolveUnknown, reconcileStale };
}

module.exports = { createShipmentService };
