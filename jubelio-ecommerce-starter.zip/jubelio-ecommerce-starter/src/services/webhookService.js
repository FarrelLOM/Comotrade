'use strict';
const logger = require('../lib/logger');
const { verifySignature } = require('../lib/signature');

/**
 * Pemrosesan webhook Jubelio (API Contract bagian 7). Webhook diatur di dashboard:
 * Setting > Developer > Webhook (URL milikmu + secret).
 *
 * Checklist endpoint webhook yang baik:
 *   [x] verifikasi signature dari RAW body
 *   [x] balas 200 SECEPATNYA, proses di belakang (route memakai setImmediate)
 *   [x] idempotent: event yang sama boleh datang berkali-kali
 *   [x] tahan urutan terbalik (lihat shouldApplyUpdate)
 *   [x] event untuk AWB yang belum kita kenal TIDAK ditandai selesai (bisa tiba sebelum
 *       respons create resi tersimpan) -> akan terkejar oleh rekonsiliasi
 */
function createWebhookService({ store, trackingService, config }) {
  function verify(rawBody, signatureHeader) {
    const secret = config.jubelio.webhookSecret;
    if (!secret) {
      if (config.env === 'production') return false; // produksi WAJIB punya secret
      logger.warn('JUBELIO_WEBHOOK_SECRET kosong: signature TIDAK diverifikasi (hanya boleh untuk development)');
      return true;
    }
    return verifySignature(rawBody, signatureHeader, secret);
  }

  function dedupKey(p) {
    const last = Array.isArray(p.tracking) ? p.tracking[p.tracking.length - 1] : p.tracking;
    return [p.awb, p.latest_status, last && last.status, last && last.date].join('|');
  }

  function handle(payload) {
    if (!payload || typeof payload !== 'object') return { handled: false, reason: 'INVALID_PAYLOAD' };
    if (payload.event !== 'awb') return { handled: false, reason: 'IGNORED_EVENT' };

    const key = dedupKey(payload);
    if (store.hasWebhookKey(key)) return { handled: false, reason: 'DUPLICATE' };

    const result = trackingService.applyStatusUpdate({
      awb: payload.awb,
      latestStatus: payload.latest_status,
      tracking: payload.tracking,
      extras: {
        deliveredImgUrl: payload.delivered_img_url,
        signImgUrl: payload.sign_img_url,
        podUrl: payload.pod_url,
        liveTrackingUrl: payload.live_tracking_url,
        trackingUrl: payload.tracking_url,
      },
      source: 'webhook',
    });

    if (result.reason === 'UNKNOWN_AWB') {
      logger.warn('Webhook untuk AWB yang belum dikenal (mungkin mendahului penyimpanan resi)', { awb: payload.awb });
      return { handled: false, reason: 'UNKNOWN_AWB' };
    }
    store.addWebhookKey(key); // tandai selesai SETELAH sukses diproses
    return { handled: true, ...result };
  }

  return { verify, handle, dedupKey };
}

module.exports = { createWebhookService };
