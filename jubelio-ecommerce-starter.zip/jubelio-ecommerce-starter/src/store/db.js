'use strict';
/**
 * Penyimpanan IN-MEMORY agar contoh bisa jalan tanpa database.
 * Data hilang saat server restart. Untuk produksi, ganti dengan database sungguhan
 * (lihat docs/skema-database.sql) dengan antarmuka yang sama.
 */
function createStore() {
  const orders = new Map();
  const awbIndex = new Map(); // awb -> orderId (webhook mencari order lewat AWB)
  const webhookKeys = new Set(); // kunci dedup webhook
  let seq = 0;

  return {
    orders: {
      nextId() {
        seq += 1;
        const d = new Date().toISOString().slice(0, 10).replaceAll('-', '');
        return `ORD-${d}-${String(seq).padStart(4, '0')}`;
      },
      get: (id) => orders.get(id) || null,
      save(order) {
        order.updatedAt = new Date().toISOString();
        orders.set(order.id, order);
        return order;
      },
      list: () => [...orders.values()],
    },
    indexAwb: (awb, orderId) => awbIndex.set(awb, orderId),
    findOrderIdByAwb: (awb) => awbIndex.get(awb) || null,
    hasWebhookKey: (k) => webhookKeys.has(k),
    addWebhookKey: (k) => webhookKeys.add(k),
  };
}

module.exports = { createStore };
