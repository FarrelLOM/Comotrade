'use strict';
const express = require('express');
const { notFound, errorHandler } = require('./middleware');

function createApp(container) {
  const app = express();
  app.disable('x-powered-by');

  // Simpan RAW body: dibutuhkan untuk verifikasi signature webhook.
  app.use(express.json({
    limit: '1mb',
    verify: (req, _res, buf) => { req.rawBody = buf.toString('utf8'); },
  }));

  app.get('/health', (_req, res) => res.json({ ok: true, jubelio: container.config.jubelio.baseUrl }));

  app.use('/api/regions', require('./routes/regions')(container));
  app.use('/api/shipping', require('./routes/shipping')(container));
  app.use('/api/orders', require('./routes/orders')(container));
  app.use('/webhooks', require('./routes/webhooks')(container));

  app.use(notFound);
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
